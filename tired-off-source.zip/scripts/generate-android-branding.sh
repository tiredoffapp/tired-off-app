#!/usr/bin/env bash
set -euo pipefail

project_root="$(cd "$(dirname "$0")/.." && pwd)"
source_icon="$project_root/public/tired-off-icon.png"
res="$project_root/android/app/src/main/res"
work_dir="$(mktemp -d)"
trap 'rm -rf "$work_dir"' EXIT

# Remove only the connected black outside corners, preserving the dark details
# inside the logo, then place the mark over the app's navy.
convert "$source_icon" -alpha on -bordercolor black -border 1 \
  -fuzz 6% -fill none -draw 'matte 0,0 floodfill' -shave 1x1 \
  "$work_dir/cutout.png"
convert -size 1254x1254 xc:'#081127' "$work_dir/cutout.png" \
  -gravity center -composite "$work_dir/icon.png"

make_icon() {
  local folder="$1" size="$2" foreground="$3"
  convert "$work_dir/icon.png" -resize "${foreground}x${foreground}" \
    -gravity center -background '#081127' -extent "${size}x${size}" \
    "$res/$folder/ic_launcher.png"
  cp "$res/$folder/ic_launcher.png" "$res/$folder/ic_launcher_round.png"
}

make_foreground() {
  local folder="$1" size="$2" artwork="$3"
  convert "$work_dir/icon.png" -resize "${artwork}x${artwork}" \
    -gravity center -background transparent -extent "${size}x${size}" \
    "$res/$folder/ic_launcher_foreground.png"
}

make_splash() {
  local file="$1" width="$2" height="$3"
  local shorter=$(( width < height ? width : height ))
  local artwork=$(( shorter * 58 / 100 ))
  convert -size "${width}x${height}" xc:'#081127' \
    \( "$work_dir/icon.png" -resize "${artwork}x${artwork}" \) \
    -gravity center -composite "$file"
}

make_icon mipmap-mdpi 48 44
make_icon mipmap-hdpi 72 66
make_icon mipmap-xhdpi 96 88
make_icon mipmap-xxhdpi 144 132
make_icon mipmap-xxxhdpi 192 176

make_foreground mipmap-mdpi 108 76
make_foreground mipmap-hdpi 162 114
make_foreground mipmap-xhdpi 216 152
make_foreground mipmap-xxhdpi 324 228
make_foreground mipmap-xxxhdpi 432 304

while IFS= read -r file; do
  dimensions="$(identify -format '%w %h' "$file")"
  make_splash "$file" $dimensions
done < <(find "$res" -path '*/splash.png' -type f | sort)

echo "Android Tired-Off icons and splash screens generated."
