import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "uk.co.tiredoff.app",
  appName: "Tired-Off",
  webDir: "mobile-web",
  server: {
    url: "https://tired-trumps.joejackson-uk.chatgpt.site",
    cleartext: false,
    allowNavigation: [
      "tired-trumps.joejackson-uk.chatgpt.site",
      "*.supabase.co",
      "accounts.google.com",
    ],
  },
  android: {
    backgroundColor: "#081127",
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1400,
      backgroundColor: "#081127",
      showSpinner: false,
    },
    StatusBar: {
      backgroundColor: "#081127",
      style: "DARK",
    },
  },
};

export default config;
