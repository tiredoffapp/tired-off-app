import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Tired-Off — Who's more tired?",
  description: "The fun daily tiredness battle for couples.",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, statusBarStyle: "black-translucent", title: "Tired-Off" },
  themeColor: "#0a1022",
  icons: {
    icon: [{ url: "/favicon-48.png", type: "image/png", sizes: "48x48" }, { url: "/icon-192.png", type: "image/png", sizes: "192x192" }],
    shortcut: "/favicon-48.png",
    apple: "/apple-touch-icon.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
