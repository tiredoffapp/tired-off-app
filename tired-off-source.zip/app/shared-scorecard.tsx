"use client";
import { useEffect, useState } from "react";
import { Layers3, Plus, SlidersHorizontal, Trash2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { supabase } from "@/lib/supabase";

export type SharedMetric = {
  id: string;
  label: string;
  min: number;
  max: number;
  step: number;
  suffix: string;
  weight: number;
  invert?: number;
  core?: boolean;
};
export type SharedCard = {
  id: string;
  emoji: string;
  label: string;
  points: number;
};
export type SharedConfig = {
  active_week: string;
  active_metrics: SharedMetric[];
  active_cards: SharedCard[];
  pending_metrics: SharedMetric[] | null;
  pending_cards: SharedCard[] | null;
  next_monday: string;
};
const metricOptions: SharedMetric[] = [
  {
    id: "commute",
    label: "Commuting",
    min: 0,
    max: 5,
    step: 0.5,
    suffix: " hrs",
    weight: 2,
  },
  {
    id: "cooking",
    label: "Cooking",
    min: 0,
    max: 5,
    step: 0.5,
    suffix: " hrs",
    weight: 2.5,
  },
  {
    id: "caring",
    label: "Caring duties",
    min: 0,
    max: 12,
    step: 0.5,
    suffix: " hrs",
    weight: 3,
  },
  {
    id: "exercise",
    label: "Exercise",
    min: 0,
    max: 5,
    step: 0.5,
    suffix: " hrs",
    weight: 2,
  },
  {
    id: "driving",
    label: "Driving",
    min: 0,
    max: 8,
    step: 0.5,
    suffix: " hrs",
    weight: 1.5,
  },
  {
    id: "onfeet",
    label: "Time on your feet",
    min: 0,
    max: 16,
    step: 0.5,
    suffix: " hrs",
    weight: 1.3,
  },
];
const cardOptions: SharedCard[] = [
  { id: "3am", emoji: "🕒", label: "3am wake-up", points: 10 },
  { id: "settle", emoji: "👶", label: "Baby wouldn’t settle", points: 15 },
  { id: "school", emoji: "🎒", label: "Early school run", points: 5 },
  { id: "commute-card", emoji: "🚗", label: "Long commute", points: 5 },
  { id: "shift", emoji: "🫠", label: "Difficult shift", points: 10 },
  { id: "overtime", emoji: "⏰", label: "Overtime", points: 15 },
  { id: "clean", emoji: "🧹", label: "Heavy cleaning day", points: 10 },
  { id: "cooked", emoji: "🍳", label: "Cooked for everyone", points: 5 },
  { id: "mental", emoji: "🧠", label: "Mental-load overload", points: 10 },
  { id: "quiet", emoji: "🌿", label: "Quiet day", points: -5 },
  { id: "takeover", emoji: "🤝", label: "Partner took over", points: -10 },
  { id: "hangover", emoji: "🍺", label: "Hangover — self-inflicted tiredness", points: -15 },
];
export function SharedScorecardEditor({
  config,
  onSaved,
}: {
  config: SharedConfig;
  onSaved: () => Promise<void>;
}) {
  const [open, setOpen] = useState(false);
  const [metrics, setMetrics] = useState<SharedMetric[]>(
    config.pending_metrics || config.active_metrics,
  );
  const [cards, setCards] = useState<SharedCard[]>(
    config.pending_cards || config.active_cards,
  );
  const [custom, setCustom] = useState("");
  const [metricWeight, setMetricWeight] = useState(2);
  const [customMetrics, setCustomMetrics] = useState<SharedMetric[]>(
    (config.pending_metrics || config.active_metrics).filter((m) => m.id.startsWith("custom-")),
  );
  const [deletedMetricIds, setDeletedMetricIds] = useState<string[]>([]);
  const [cardName, setCardName] = useState("");
  const [emoji, setEmoji] = useState("😵");
  const [points, setPoints] = useState(10);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [draftLoaded, setDraftLoaded] = useState(false);
  const draftKey = `tired-off-scorecard-draft:${config.next_monday}`;
  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(draftKey) || "null");
      if (Array.isArray(saved?.metrics)) setMetrics(saved.metrics);
      if (Array.isArray(saved?.cards)) setCards(saved.cards);
      if (Array.isArray(saved?.customMetrics)) setCustomMetrics(saved.customMetrics);
      if (Array.isArray(saved?.deletedMetricIds)) setDeletedMetricIds(saved.deletedMetricIds);
    } catch {
      // Ignore a damaged local planning draft.
    }
    setDraftLoaded(true);
  }, [draftKey]);
  useEffect(() => {
    if (!draftLoaded) return;
    localStorage.setItem(draftKey, JSON.stringify({ metrics, cards, customMetrics, deletedMetricIds }));
  }, [cards, customMetrics, deletedMetricIds, draftKey, draftLoaded, metrics]);
  function toggleMetric(m: SharedMetric) {
    if (metrics.some((x) => x.id === m.id)) {
      if (m.core) return;
      setMetrics(metrics.filter((x) => x.id !== m.id));
    } else if (metrics.length < 10) {
      setMetrics([...metrics, m]);
      setMessage(`${m.label} selected for next week.`);
    } else {
      setMessage("You can use 10 measurements each week. Remove an optional one before selecting another.");
    }
  }
  function deleteMetric(m: SharedMetric) {
    if (!m.id.startsWith("custom-") || m.core) return;
    setMetrics(metrics.filter((x) => x.id !== m.id));
    setCustomMetrics(customMetrics.filter((x) => x.id !== m.id));
    setDeletedMetricIds([...deletedMetricIds, m.id]);
    setMessage(`${m.label} removed from next week's choices.`);
  }
  function toggleCard(c: SharedCard) {
    setCards(
      cards.some((x) => x.id === c.id)
        ? cards.filter((x) => x.id !== c.id)
        : cards.length < 12
          ? [...cards, c]
          : cards,
    );
  }
  function addMetric() {
    const label = custom.trim();
    if (!label) {
      setMessage("Give your measurement a name first.");
      return;
    }
    if (customMetrics.some((m) => m.label.toLowerCase() === label.toLowerCase())) {
      setMessage("You already have a custom measurement with that name.");
      return;
    }
    const id = typeof crypto.randomUUID === "function"
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
    const newMetric: SharedMetric = {
      id: `custom-${id}`,
      label,
      min: 0,
      max: 5,
      step: 1,
      suffix: "/5",
      weight: metricWeight,
    };
    setCustomMetrics([...customMetrics, newMetric]);
    if (metrics.length < 10) setMetrics([...metrics, newMetric]);
    setCustom("");
    setMessage(metrics.length < 10
      ? `${label} added — worth up to ${metricWeight * 5} points.`
      : `${label} saved as a choice. Remove an optional measurement, then tap it to select it.`);
  }
  function addCard() {
    const label = cardName.trim();
    if (!label || cards.length >= 12) return;
    setCards([
      ...cards,
      {
        id: `custom-${crypto.randomUUID()}`,
        emoji: emoji || "😵",
        label,
        points,
      },
    ]);
    setCardName("");
  }
  async function save() {
    setBusy(true);
    setMessage("");
    const { error } = await supabase.rpc("save_shared_scorecard", {
      p_metrics: metrics,
      p_cards: cards,
    });
    if (error) setMessage(error.message);
    else {
      await onSaved();
      setMessage("Saved for next Monday on both phones.");
    }
    setBusy(false);
  }
  const allMetrics = [...metrics, ...customMetrics, ...config.active_metrics, ...metricOptions]
    .filter((m) => !deletedMetricIds.includes(m.id))
    .filter((m, i, a) => a.findIndex((x) => x.id === m.id) === i);
  const allCards = [...config.active_cards, ...cardOptions].filter(
    (c, i, a) => a.findIndex((x) => x.id === c.id) === i,
  );
  return (
    <>
      <div className="shared-setup-bar">
        <div>
          <strong>Shared weekly setup</strong>
          <span>
            {config.pending_metrics
              ? "Changes queued for next Monday"
              : "This scorecard is locked for the week"}
          </span>
        </div>
        <Button variant="outline" onClick={() => setOpen(true)}>
          <SlidersHorizontal />
          Plan next week
        </Button>
      </div>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="shared-setup-dialog">
          <DialogHeader>
            <DialogTitle>Next week&apos;s shared setup</DialogTitle>
            <DialogDescription>
              Either partner can edit this. The same choices start for both of
              you next Monday.
            </DialogDescription>
          </DialogHeader>
          <section>
            <h3>
              <SlidersHorizontal />
              Measurements <small>{metrics.length}/10</small>
            </h3>
            <div className="shared-choice-grid">
              {allMetrics.map((m) => (
                <div className="shared-choice-wrap" key={m.id}>
                  <button
                    type="button"
                    className={
                      metrics.some((x) => x.id === m.id)
                        ? "shared-choice selected"
                        : "shared-choice"
                    }
                    onClick={() => toggleMetric(m)}
                  >
                    <span>{m.label}</span>
                    <b>
                      {m.core
                        ? "Fixed"
                        : metrics.some((x) => x.id === m.id)
                          ? m.id.startsWith("custom-")
                            ? `×${m.weight} pts`
                            : "✓"
                          : "＋"}
                    </b>
                  </button>
                  {m.id.startsWith("custom-") && !m.core && (
                    <button
                      type="button"
                      className="shared-choice-delete"
                      onClick={() => deleteMetric(m)}
                      aria-label={`Delete ${m.label}`}
                    >
                      <Trash2 />
                    </button>
                  )}
                </div>
              ))}
            </div>
            <div className="shared-add">
              <input
                value={custom}
                onChange={(e) => setCustom(e.target.value)}
                placeholder="Custom rating, e.g. School runs"
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    addMetric();
                  }
                }}
              />
              <label className="metric-points-select">
                <span>Points per level</span>
                <select
                  value={metricWeight}
                  onChange={(e) => setMetricWeight(Number(e.target.value))}
                >
                  <option value={1}>1 · up to 5</option>
                  <option value={2}>2 · up to 10</option>
                  <option value={3}>3 · up to 15</option>
                </select>
              </label>
              <Button onClick={addMetric}>
                <Plus />
                Add
              </Button>
            </div>
          </section>
          <section>
            <h3>
              <Layers3 />
              Exhaustion cards <small>{cards.length}/12</small>
            </h3>
            <div className="shared-choice-grid cards">
              {allCards.map((c) => (
                <button
                  type="button"
                  className={
                    cards.some((x) => x.id === c.id)
                      ? "shared-choice selected"
                      : "shared-choice"
                  }
                  onClick={() => toggleCard(c)}
                  key={c.id}
                >
                  <span>
                    {c.emoji} {c.label}
                  </span>
                  <b>
                    {cards.some((x) => x.id === c.id)
                      ? "✓"
                      : c.points > 0
                        ? `+${c.points}`
                        : c.points}
                  </b>
                </button>
              ))}
            </div>
            <div className="shared-custom-card">
              <input
                className="emoji"
                value={emoji}
                onChange={(e) => setEmoji(e.target.value)}
                maxLength={3}
              />
              <input
                value={cardName}
                onChange={(e) => setCardName(e.target.value)}
                placeholder="Custom card"
              />
              <select
                value={points}
                onChange={(e) => setPoints(Number(e.target.value))}
              >
                {[-15, -10, -5, 5, 10, 15].map((n) => (
                  <option value={n} key={n}>
                    {n > 0 ? "+" : ""}
                    {n}
                  </option>
                ))}
              </select>
              <Button onClick={addCard}>
                <Plus />
              </Button>
            </div>
          </section>
          {message && <p className="shared-setup-message">{message}</p>}
          <Button
            size="lg"
            disabled={busy || metrics.length < 4 || cards.length < 4}
            onClick={save}
          >
            {busy ? "Saving…" : "Save for next Monday"}
          </Button>
          <button
            className="shared-close"
            onClick={() => setOpen(false)}
            aria-label="Close"
          >
            <X />
          </button>
        </DialogContent>
      </Dialog>
    </>
  );
}
