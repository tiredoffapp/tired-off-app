"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { Bell, MessageCircle, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/lib/supabase";
import {
  enableNativeNotifications,
  nativeNotificationsEnabled,
  supportsNativeNotifications,
} from "@/lib/native-notifications";
import "./tired-talk.css";

const lines = [
  { id: "walking_to_work", text: "I’m already tired and I’ve only just left the house 😴" },
  { id: "running_on_fumes", text: "Running on fumes today. Send snacks." },
  { id: "tea_please", text: "Any chance of a cup of tea? ☕" },
  { id: "sofa_claim", text: "I’m claiming five minutes on the sofa." },
  { id: "take_over", text: "Could you take over for 20 minutes? ❤️" },
  { id: "nap_request", text: "I would like to formally request a nap." },
  { id: "score_suspicious", text: "Your tiredness score is suspiciously low 👀" },
  { id: "proud_of_you", text: "You’re doing brilliantly. Nearly there ❤️" },
  { id: "truce", text: "Truce? Let’s order dinner." },
  { id: "on_my_way", text: "On my way home. Save me a seat." },
  { id: "rough_night", text: "That was a rough night. We’ve got this." },
  { id: "you_win_today", text: "I concede. You win the tiredness crown today 👑" },
] as const;

type TalkMessage = {
  id: string;
  sender_id: string;
  recipient_id: string;
  message_id: string;
  message_text?: string | null;
  created_at: string;
  read_at: string | null;
};

const messageText = (id: string, custom?: string | null) =>
  id === "custom" ? custom || "Tired Talk" : lines.find((line) => line.id === id)?.text ?? "Tired Talk";

export function TiredTalk({ user, coupleId, active, onUnreadChange }: { user: User; coupleId: string; active: boolean; onUnreadChange: (count: number) => void }) {
  const [messages, setMessages] = useState<TalkMessage[]>([]);
  const [recipientId, setRecipientId] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [unread, setUnread] = useState(0);
  const [notifications, setNotifications] = useState(() => nativeNotificationsEnabled());
  const [typedMessage, setTypedMessage] = useState("");
  const knownIds = useRef<Set<string> | null>(null);
  const historyRef = useRef<HTMLDivElement | null>(null);
  const activeRef = useRef(active);
  activeRef.current = active;

  const refresh = useCallback(async () => {
    const { data, error: fetchError } = await supabase
      .from("tired_talk_messages")
      .select("*")
      .eq("couple_id", coupleId)
      .order("created_at", { ascending: false })
      .limit(60);
    if (fetchError) {
      setError("Tired Talk needs its database setup before messages can be sent.");
      return;
    }
    const next = (data || []) as TalkMessage[];
    if (knownIds.current && "Notification" in window && Notification.permission === "granted" && !activeRef.current) {
      for (const item of [...next].reverse()) {
        if (item.recipient_id === user.id && !knownIds.current.has(item.id)) {
          navigator.serviceWorker?.ready.then((registration) => registration.showNotification("Tired Talk 💬", {
            body: messageText(item.message_id, item.message_text), icon: "/icon-192.png", tag: item.id,
          })).catch(() => undefined);
        }
      }
    }
    knownIds.current = new Set(next.map((item) => item.id));
    setMessages(next);
    const count = next.filter((item) => item.recipient_id === user.id && !item.read_at).length;
    setUnread(count);
    onUnreadChange(count);
    setError("");
  }, [coupleId, user.id, onUnreadChange]);

  useEffect(() => {
    knownIds.current = null;
    supabase.from("couple_members").select("user_id")
      .eq("couple_id", coupleId).neq("user_id", user.id).maybeSingle()
      .then(({ data }) => setRecipientId(data?.user_id ?? null));
    void refresh();
    const timer = window.setInterval(() => void refresh(), 15000);
    const onVisible = () => { if (document.visibilityState === "visible") void refresh(); };
    document.addEventListener("visibilitychange", onVisible);
    return () => { window.clearInterval(timer); document.removeEventListener("visibilitychange", onVisible); };
  }, [coupleId, user.id, refresh]);

  useEffect(() => {
    if (!active) return;
    const unreadIds = messages.filter((item) => item.recipient_id === user.id && !item.read_at).map((item) => item.id);
    if (!unreadIds.length) return;
    void supabase.from("tired_talk_messages")
      .update({ read_at: new Date().toISOString() })
      .eq("couple_id", coupleId).eq("recipient_id", user.id).in("id", unreadIds)
      .then(({ error }) => { if (!error) { setUnread(0); onUnreadChange(0); } });
  }, [active, messages, coupleId, user.id, onUnreadChange]);

  useEffect(() => {
    if (!active || !historyRef.current) return;
    const frame = window.requestAnimationFrame(() => {
      if (historyRef.current)
        historyRef.current.scrollTo({ top: historyRef.current.scrollHeight, behavior: "smooth" });
    });
    return () => window.cancelAnimationFrame(frame);
  }, [active, messages.length]);

  async function send(id: string) {
    if (!recipientId || busy) return;
    setBusy(id);
    const { data: sent, error: sendError } = await supabase.from("tired_talk_messages").insert({
      couple_id: coupleId, sender_id: user.id, recipient_id: recipientId, message_id: id,
    }).select("id").single();
    if (sendError) setError(sendError.message);
    else {
      if (sent?.id) void supabase.functions.invoke("send-tired-talk-push", { body: { message_id: sent.id } });
      await refresh();
    }
    setBusy(null);
  }

  async function sendTyped() {
    const text = typedMessage.trim();
    if (!recipientId || busy || !text) return;
    setBusy("custom");
    setError("");
    const { data: sent, error: sendError } = await supabase.from("tired_talk_messages").insert({
      couple_id: coupleId,
      sender_id: user.id,
      recipient_id: recipientId,
      message_id: "custom",
      message_text: text.slice(0, 300),
    }).select("id").single();
    if (sendError) setError("Typed messages need the latest Tired Talk database update.");
    else {
      setTypedMessage("");
      if (sent?.id) void supabase.functions.invoke("send-tired-talk-push", { body: { message_id: sent.id } });
      await refresh();
    }
    setBusy(null);
  }

  async function enableNotifications() {
    if (supportsNativeNotifications()) {
      const enabled = await enableNativeNotifications();
      setNotifications(enabled);
      if (!enabled) setError("Notifications are switched off for Tired-Off in your phone settings.");
      return;
    }
    if (!("Notification" in window)) return;
    const permission = await Notification.requestPermission();
    setNotifications(permission === "granted");
  }

  return (
    <section className="talk-panel" aria-label="Tired Talk">
      <div className="talk-heading">
        <div><span className="eyebrow">JUST BETWEEN YOU TWO</span><h2><MessageCircle /> Tired Talk</h2>
          <p>Send a little nudge, a kind word, or a tired confession.</p></div>
        {unread > 0 && <span className="talk-unread" aria-label={`${unread} unread messages`}>{unread} new</span>}
      </div>
      {active && <>
        <div className="talk-notifications">
          <Bell size={18} />
          <span>{notifications || (!supportsNativeNotifications() && typeof Notification !== "undefined" && Notification.permission === "granted")
            ? supportsNativeNotifications() ? "Phone notifications are on—even when Tired-Off is closed." : "Notifications are on while this app is running."
            : supportsNativeNotifications() ? "Get Tired Talk alerts even when the app is closed." : "Get a phone alert when Tired-Off is running."}</span>
          {supportsNativeNotifications() && !notifications &&
            <Button variant="outline" onClick={enableNotifications}>Enable</Button>}
          {!supportsNativeNotifications() && typeof Notification !== "undefined" && Notification.permission === "default" &&
            <Button variant="outline" onClick={enableNotifications}>Enable</Button>}
        </div>
        <h3>Send one to your partner</h3>
        <div className="talk-choices">
          {lines.map((line) => <button key={line.id} type="button" disabled={!recipientId || !!busy}
            onClick={() => void send(line.id)}>{line.text}<Send size={16} /></button>)}
        </div>
        <h3>Or write your own</h3>
        <div className="talk-compose">
          <textarea
            value={typedMessage}
            maxLength={300}
            rows={3}
            placeholder="Type a message to your partner…"
            onChange={(e) => setTypedMessage(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void sendTyped();
              }
            }}
          />
          <div>
            <small>{typedMessage.length}/300</small>
            <Button disabled={!recipientId || !!busy || !typedMessage.trim()} onClick={() => void sendTyped()}>
              <Send /> {busy === "custom" ? "Sending…" : "Send message"}
            </Button>
          </div>
        </div>
        <h3>Recent messages</h3>
        <div className="talk-history" ref={historyRef} aria-live="polite">
          {!messages.length && <p>No messages yet. Send the first one!</p>}
          {[...messages].reverse().map((item) => <div className={item.sender_id === user.id ? "talk-bubble mine" : "talk-bubble"} key={item.id}>
            <span>{item.sender_id === user.id ? "You" : "Partner"} · {new Date(item.created_at).toLocaleString([], { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" })}</span>
            <p>{messageText(item.message_id, item.message_text)}</p>
          </div>)}
        </div>
        {error && <p className="talk-error" role="alert">{error}</p>}
      </>}
    </section>
  );
}
