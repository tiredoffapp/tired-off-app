"use client";

import { useEffect, useMemo, useState } from "react";
import {
  ArrowRight,
  Award,
  BarChart3,
  BedDouble,
  Briefcase,
  CheckCircle2,
  Crown,
  Gift,
  Heart,
  HelpCircle,
  Home,
  Layers3,
  LockKeyhole,
  Moon,
  MessageCircle,
  Plus,
  RotateCcw,
  Save,
  Settings,
  Shuffle,
  SlidersHorizontal,
  Sparkles,
  Trophy,
  UserRound,
  Users,
  type LucideIcon,
} from "lucide-react";
import type { User } from "@supabase/supabase-js";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AuthPanel } from "@/app/auth-panel";
import { OnlineBattle } from "@/app/online-battle";
import { TiredTalk } from "@/app/tired-talk";
import { OnlineChampionship, OnlineRewards } from "@/app/online-season";
import { supabase, supabaseConfigured } from "@/lib/supabase";
import { listenForNativeAuth } from "@/lib/native-auth";
import { restoreNativeNotifications } from "@/lib/native-notifications";

type Player = {
  name: string;
  sleep: number;
  work: number;
  wakeups: number;
  awake: number;
  chores: number;
  childcare: number;
  stress: number;
  physical: number;
  extras: Record<string, number>;
  cards: string[];
};
type Result = {
  id: string;
  date: string;
  a: { name: string; score: number };
  b: { name: string; score: number };
  winner: string;
  margin: number;
};
type RewardRound = {
  week: string;
  champion: string;
  cards: string[];
  picked: string | null;
  swapped: boolean;
};
type RestReward = {
  id: string;
  week: string;
  champion: string;
  reward: string;
  completedAt: string;
};
type ExhaustionCard = {
  id: string;
  emoji: string;
  title: string;
  points: number;
  custom?: boolean;
};
type CustomMetric = {
  id: string;
  label: string;
  emoji: string;
  unit: "hours" | "minutes" | "count" | "rating";
  impact: "low" | "medium" | "high";
};
type MetricDefinition = {
  id: string;
  label: string;
  icon: LucideIcon;
  min: number;
  max: number;
  step: number;
  suffix: string;
  score: (value: number) => number;
  core?: boolean;
  emoji?: string;
};
type PlayStyle = "fair" | "funny" | "survival";

const defaultPlayer = (name: string): Player => ({
  name,
  sleep: 7,
  work: 8,
  wakeups: 1,
  awake: 20,
  chores: 2,
  childcare: 2,
  stress: 3,
  physical: 1,
  extras: {},
  cards: [],
});
const cardLibrary: ExhaustionCard[] = [
  { id: "sick", emoji: "🤒", title: "Sick child", points: 15 },
  { id: "3am", emoji: "🕒", title: "3am wake-up", points: 10 },
  { id: "feed", emoji: "🍼", title: "Night feed", points: 12 },
  { id: "snore", emoji: "💤", title: "Partner snored", points: 5 },
  { id: "liein", emoji: "🛏️", title: "Had a lie-in", points: -10 },
  { id: "eight", emoji: "✨", title: "8 hours uninterrupted", points: -15 },
  { id: "settle", emoji: "👶", title: "Baby wouldn’t settle", points: 15 },
  { id: "school", emoji: "🎒", title: "Early school run", points: 5 },
  { id: "late", emoji: "💼", title: "Worked late", points: 10 },
  { id: "commute", emoji: "🚗", title: "Long commute", points: 5 },
  { id: "shift", emoji: "🫠", title: "Difficult shift", points: 10 },
  { id: "overtime", emoji: "⏰", title: "Overtime", points: 15 },
  { id: "clean", emoji: "🧹", title: "Heavy cleaning day", points: 10 },
  { id: "cooked", emoji: "🍳", title: "Cooked for everyone", points: 5 },
  { id: "mental", emoji: "🧠", title: "Mental-load overload", points: 10 },
  { id: "exercise", emoji: "🏋️", title: "Exercised hard", points: 5 },
  { id: "nap", emoji: "😌", title: "Afternoon nap", points: -10 },
  { id: "quiet", emoji: "🌿", title: "Quiet day", points: -5 },
  { id: "takeover", emoji: "🤝", title: "Partner took over", points: -10 },
  { id: "hangover", emoji: "🍺", title: "Hangover — self-inflicted tiredness", points: -15 },
];
const defaultCardIds = [
  "sick",
  "3am",
  "feed",
  "snore",
  "liein",
  "eight",
  "mental",
  "takeover",
];
const starterRewards = [
  "Two-hour uninterrupted nap",
  "20-minute foot rub",
  "Shoulder or back massage",
  "Breakfast in bed",
  "A proper lie-in",
  "Evening off household duties",
  "Bedtime duty covered",
  "Favourite meal cooked or ordered",
  "Control of the TV for an evening",
  "A hot bath with no interruptions",
  "Tea or coffee in bed",
  "One chore wiped from the list",
  "An uninterrupted hour to yourself",
  "Choice of the next date night",
  "A favourite snack or small treat",
  "No-questions-asked early night",
];

function weekKey(dateValue = new Date()) {
  const d = new Date(dateValue);
  d.setHours(0, 0, 0, 0);
  const day = (d.getDay() + 6) % 7;
  d.setDate(d.getDate() - day);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function weekUnlock(key: string) {
  const d = new Date(`${key}T19:00:00`);
  d.setDate(d.getDate() + 6);
  return d;
}
function sampleRewards(pool: string[], count = 3) {
  return [...pool]
    .sort(() => Math.random() - 0.5)
    .slice(0, Math.min(count, pool.length));
}

const coreMetricIds = ["sleep", "work", "wakeups", "awake"];
const defaultMetricIds = [
  ...coreMetricIds,
  "chores",
  "childcare",
  "stress",
  "physical",
];
const metricLibrary: MetricDefinition[] = [
  {
    id: "sleep",
    label: "Hours slept",
    icon: BedDouble,
    min: 0,
    max: 12,
    step: 0.5,
    suffix: " hrs",
    score: (v) => Math.max(0, 8 - v) * 8,
    core: true,
  },
  {
    id: "work",
    label: "Hours worked",
    icon: Briefcase,
    min: 0,
    max: 16,
    step: 0.5,
    suffix: " hrs",
    score: (v) => v * 1.6,
    core: true,
  },
  {
    id: "wakeups",
    label: "Night wake-ups",
    icon: Moon,
    min: 0,
    max: 10,
    step: 1,
    suffix: "",
    score: (v) => v * 5,
    core: true,
  },
  {
    id: "awake",
    label: "Minutes awake overnight",
    icon: Moon,
    min: 0,
    max: 240,
    step: 10,
    suffix: " min",
    score: (v) => v * 0.07,
    core: true,
  },
  {
    id: "chores",
    label: "Housework",
    icon: Home,
    min: 0,
    max: 8,
    step: 0.5,
    suffix: " hrs",
    score: (v) => v * 3,
  },
  {
    id: "childcare",
    label: "Childcare",
    icon: Users,
    min: 0,
    max: 24,
    step: 0.5,
    suffix: " hrs",
    score: (v) => v * (new Date() >= new Date("2026-09-28T00:00:00") ? 4 : 3),
  },
  {
    id: "stress",
    label: "Stress / mental load",
    icon: Sparkles,
    min: 0,
    max: 5,
    step: 1,
    suffix: "/5",
    score: (v) => v * 4,
  },
  {
    id: "physical",
    label: "Physical effort",
    icon: BarChart3,
    min: 0,
    max: 5,
    step: 1,
    suffix: "/5",
    score: (v) => v * 2,
  },
  {
    id: "commute",
    label: "Commuting",
    icon: Briefcase,
    min: 0,
    max: 5,
    step: 0.5,
    suffix: " hrs",
    score: (v) => v * 2,
  },
  {
    id: "cooking",
    label: "Cooking",
    icon: Home,
    min: 0,
    max: 5,
    step: 0.5,
    suffix: " hrs",
    score: (v) => v * 2.5,
  },
  {
    id: "caring",
    label: "Caring duties",
    icon: Heart,
    min: 0,
    max: 12,
    step: 0.5,
    suffix: " hrs",
    score: (v) => v * 3,
  },
  {
    id: "exercise",
    label: "Exercise",
    icon: BarChart3,
    min: 0,
    max: 5,
    step: 0.5,
    suffix: " hrs",
    score: (v) => v * 2,
  },
  {
    id: "driving",
    label: "Driving",
    icon: Briefcase,
    min: 0,
    max: 8,
    step: 0.5,
    suffix: " hrs",
    score: (v) => v * 1.5,
  },
  {
    id: "onfeet",
    label: "Time on your feet",
    icon: Users,
    min: 0,
    max: 16,
    step: 0.5,
    suffix: " hrs",
    score: (v) => v * 1.3,
  },
];
function customMetricDefinition(m: CustomMetric): MetricDefinition {
  const scale = { low: 1, medium: 1.6, high: 2.3 }[m.impact];
  const setup = {
    hours: { max: 12, step: 0.5, suffix: " hrs", normal: 1 },
    minutes: { max: 240, step: 10, suffix: " min", normal: 0.04 },
    count: { max: 20, step: 1, suffix: "", normal: 1 },
    rating: { max: 5, step: 1, suffix: "/5", normal: 2 },
  }[m.unit];
  return {
    id: m.id,
    label: m.label,
    emoji: m.emoji,
    icon: SlidersHorizontal,
    min: 0,
    max: setup.max,
    step: setup.step,
    suffix: setup.suffix,
    score: (v) => v * setup.normal * scale,
  };
}
function metricValue(p: Player, id: string) {
  return id in p
    ? Number((p as unknown as Record<string, unknown>)[id] ?? 0)
    : Number(p.extras?.[id] ?? 0);
}
function setMetricValue(p: Player, id: string, value: number): Player {
  return id in p
    ? { ...p, [id]: value }
    : { ...p, extras: { ...(p.extras || {}), [id]: value } };
}
function score(
  p: Player,
  cards: ExhaustionCard[],
  activeMetrics: MetricDefinition[],
) {
  const base = activeMetrics.reduce(
    (sum, m) => sum + m.score(metricValue(p, m.id)),
    0,
  );
  const cardScore = p.cards.reduce(
    (sum, id) => sum + (cards.find((c) => c.id === id)?.points ?? 0),
    0,
  );
  return Math.max(0, Math.min(100, Math.round(base + cardScore)));
}
function tiredLabel(n: number) {
  if (n >= 85) return "Running on fumes";
  if (n >= 70) return "Absolutely exhausted";
  if (n >= 55) return "Seriously tired";
  if (n >= 40) return "Definitely tired";
  if (n >= 25) return "A bit weary";
  return "Suspiciously well rested";
}
function PlayerCard({
  player,
  setPlayer,
  colour,
  cards,
  metrics,
}: {
  player: Player;
  setPlayer: (p: Player) => void;
  colour: "coral" | "blue";
  cards: ExhaustionCard[];
  metrics: MetricDefinition[];
}) {
  const total = score(player, cards, metrics);
  return (
    <section className={`player-card ${colour}`}>
      <div className="player-top">
        <input
          aria-label="Player name"
          value={player.name}
          onChange={(e) => setPlayer({ ...player, name: e.target.value })}
        />
        <div className="score-orb">
          <strong>{total}</strong>
          <span>/100</span>
        </div>
      </div>
      <p className="tired-label">{tiredLabel(total)}</p>
      <div className="meter">
        <span style={{ width: `${total}%` }} />
      </div>
      <div className="metrics">
        {metrics.map((m) => {
          const Icon = m.icon;
          const value = metricValue(player, m.id);
          return (
            <label className="metric" key={m.id}>
              <span className="metric-label">
                <span>
                  {m.emoji ? (
                    <i className="metric-emoji">{m.emoji}</i>
                  ) : (
                    <Icon />
                  )}
                  {m.label}
                </span>
                <b>
                  {value}
                  {m.suffix}
                </b>
              </span>
              <Slider
                min={m.min}
                max={m.max}
                step={m.step}
                value={[value]}
                onValueChange={(v) =>
                  setPlayer(setMetricValue(player, m.id, v[0]))
                }
                aria-label={`${player.name} ${m.label}`}
              />
            </label>
          );
        })}
      </div>
      <div className="cards-title">Today&apos;s exhaustion cards</div>
      <div className="special-cards">
        {cards.map((c) => {
          const active = player.cards.includes(c.id);
          return (
            <button
              type="button"
              key={c.id}
              className={active ? "special active" : "special"}
              aria-pressed={active}
              onClick={() =>
                setPlayer({
                  ...player,
                  cards: active
                    ? player.cards.filter((id) => id !== c.id)
                    : [...player.cards, c.id],
                })
              }
            >
              <span>{c.emoji}</span>
              <span>
                {c.title}
                <small>
                  {c.points > 0 ? "+" : ""}
                  {c.points}
                </small>
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
}

export default function HomePage() {
  const [a, setA] = useState<Player>(() => defaultPlayer("Joe"));
  const [b, setB] = useState<Player>(() => defaultPlayer("Partner"));
  const [history, setHistory] = useState<Result[]>([]);
  const [saved, setSaved] = useState(false);
  const [ready, setReady] = useState(false);
  const [rewardRound, setRewardRound] = useState<RewardRound | null>(null);
  const [hall, setHall] = useState<RestReward[]>([]);
  const [customRewards, setCustomRewards] = useState<string[]>([]);
  const [hiddenRewards, setHiddenRewards] = useState<string[]>([]);
  const [newReward, setNewReward] = useState("");
  const [rulesOpen, setRulesOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [theme, setTheme] = useState<"midnight" | "daylight" | "pink" | "lazy">("midnight");
  const [playStyle, setPlayStyle] = useState<PlayStyle>("fair");
  const [largeText, setLargeText] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [accountName, setAccountName] = useState("");
  const [accountMessage, setAccountMessage] = useState("");
  const [accountBusy, setAccountBusy] = useState(false);
  const [dangerAction, setDangerAction] = useState<"unpair" | "delete" | null>(null);
  const [playIntroOpen, setPlayIntroOpen] = useState(false);
  const [now, setNow] = useState(() => new Date());
  const [deckOpen, setDeckOpen] = useState(false);
  const [activeCardIds, setActiveCardIds] = useState<string[]>(defaultCardIds);
  const [customCards, setCustomCards] = useState<ExhaustionCard[]>([]);
  const [cardTitle, setCardTitle] = useState("");
  const [cardEmoji, setCardEmoji] = useState("😵");
  const [cardPoints, setCardPoints] = useState(10);
  const [deckMessage, setDeckMessage] = useState("");
  const [scorecardOpen, setScorecardOpen] = useState(false);
  const [activeMetricIds, setActiveMetricIds] =
    useState<string[]>(defaultMetricIds);
  const [pendingMetricIds, setPendingMetricIds] = useState<string[] | null>(
    null,
  );
  const [customMetrics, setCustomMetrics] = useState<CustomMetric[]>([]);
  const [scorecardWeek, setScorecardWeek] = useState(() => weekKey());
  const [metricLabel, setMetricLabel] = useState("");
  const [metricEmoji, setMetricEmoji] = useState("⚡");
  const [metricUnit, setMetricUnit] = useState<CustomMetric["unit"]>("hours");
  const [metricImpact, setMetricImpact] =
    useState<CustomMetric["impact"]>("medium");
  const [scorecardMessage, setScorecardMessage] = useState("");
  const [showWelcome, setShowWelcome] = useState<boolean | null>(null);
  const [accountReady, setAccountReady] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const [accountUser, setAccountUser] = useState<User | null>(null);
  const [coupleId, setCoupleId] = useState<string | null>(null);
  const [coupleReady, setCoupleReady] = useState(false);
  const [currentTab, setCurrentTab] = useState("battle");
  const [talkUnread, setTalkUnread] = useState(0);
  const [isOnline, setIsOnline] = useState(true);
  useEffect(() => {
    try {
      const s = JSON.parse(
        localStorage.getItem("tired-off-state") ||
          localStorage.getItem("tired-trumps-state") ||
          "null",
      );
      if (s?.a)
        setA({
          ...defaultPlayer(s.a.name || "Joe"),
          ...s.a,
          extras: s.a.extras || {},
        });
      if (s?.b)
        setB({
          ...defaultPlayer(s.b.name || "Partner"),
          ...s.b,
          extras: s.b.extras || {},
        });
      if (Array.isArray(s?.history)) setHistory(s.history);
      if (s?.rewardRound) setRewardRound(s.rewardRound);
      if (Array.isArray(s?.hall)) setHall(s.hall);
      if (Array.isArray(s?.customRewards)) setCustomRewards(s.customRewards);
      if (Array.isArray(s?.hiddenRewards)) setHiddenRewards(s.hiddenRewards);
      if (Array.isArray(s?.activeCardIds)) setActiveCardIds(s.activeCardIds);
      if (Array.isArray(s?.customCards)) setCustomCards(s.customCards);
      if (Array.isArray(s?.activeMetricIds))
        setActiveMetricIds(s.activeMetricIds);
      if (Array.isArray(s?.pendingMetricIds))
        setPendingMetricIds(s.pendingMetricIds);
      if (Array.isArray(s?.customMetrics)) setCustomMetrics(s.customMetrics);
      if (typeof s?.scorecardWeek === "string") {
        const current = weekKey();
        if (s.scorecardWeek !== current && Array.isArray(s.pendingMetricIds)) {
          setActiveMetricIds([
            ...new Set([...coreMetricIds, ...s.pendingMetricIds]),
          ]);
          setPendingMetricIds(null);
        }
        setScorecardWeek(current);
      }
    } catch {}
    setReady(true);
    if ("serviceWorker" in navigator) {
      let refreshing = false;
      navigator.serviceWorker.addEventListener("controllerchange", () => {
        if (!refreshing) {
          refreshing = true;
          window.location.reload();
        }
      });
      navigator.serviceWorker
        .register("/sw.js")
        .then((reg) => reg.update())
        .catch(() => undefined);
    }
  }, []);
  useEffect(() => {
    setShowWelcome(localStorage.getItem("tired-off-welcomed") !== "yes");
  }, []);
  useEffect(() => {
    const key = accountUser ? `tired-off-theme:${accountUser.id}` : "tired-off-theme:device";
    const saved = localStorage.getItem(key) || localStorage.getItem("tired-off-theme:device");
    if (["midnight", "daylight", "pink", "lazy"].includes(saved || ""))
      setTheme(saved as typeof theme);
  }, [accountUser]);
  useEffect(() => {
    document.documentElement.dataset.tiredTheme = theme;
    const key = accountUser ? `tired-off-theme:${accountUser.id}` : "tired-off-theme:device";
    localStorage.setItem(key, theme);
    localStorage.setItem("tired-off-theme:device", theme);
  }, [accountUser, theme]);
  useEffect(() => {
    const owner = accountUser?.id || "device";
    const storedStyle = localStorage.getItem(`tired-off-play-style:${owner}`);
    if (["fair", "funny", "survival"].includes(storedStyle || ""))
      setPlayStyle(storedStyle as PlayStyle);
    setLargeText(localStorage.getItem(`tired-off-large-text:${owner}`) === "yes");
    setReducedMotion(localStorage.getItem(`tired-off-reduced-motion:${owner}`) === "yes");
    setAccountName(String(accountUser?.user_metadata?.display_name || accountUser?.email?.split("@")[0] || ""));
  }, [accountUser]);
  useEffect(() => {
    const owner = accountUser?.id || "device";
    localStorage.setItem(`tired-off-play-style:${owner}`, playStyle);
    localStorage.setItem(`tired-off-large-text:${owner}`, largeText ? "yes" : "no");
    localStorage.setItem(`tired-off-reduced-motion:${owner}`, reducedMotion ? "yes" : "no");
    document.documentElement.dataset.largeText = largeText ? "yes" : "no";
    document.documentElement.dataset.reducedMotion = reducedMotion ? "yes" : "no";
  }, [accountUser, playStyle, largeText, reducedMotion]);
  useEffect(() => {
    if (!supabaseConfigured) {
      setAccountReady(true);
      return;
    }
    let active = true;
    supabase.auth.getSession().then(({ data }) => {
      if (!active) return;
      setAccountUser(data.session?.user || null);
      setAccountOpen(
        !data.session && !localStorage.getItem("tired-off-auth-skipped"),
      );
      setAccountReady(true);
    });
    const { data } = supabase.auth.onAuthStateChange((event, session) => {
      if (active) setAccountUser(session?.user || null);
      if (event === "PASSWORD_RECOVERY") {
        localStorage.setItem("tired-off-password-recovery", "yes");
        setAccountOpen(true);
      }
    });
    return () => {
      active = false;
      data.subscription.unsubscribe();
    };
  }, []);
  useEffect(() => {
    let stop: (() => void) | undefined;
    listenForNativeAuth((message) => window.alert(message)).then((cleanup) => {
      stop = cleanup;
    });
    return () => stop?.();
  }, []);
  useEffect(() => {
    if (!accountUser) {
      setCoupleId(null);
      setCoupleReady(true);
      return;
    }
    let active = true;
    setCoupleReady(false);
    supabase.rpc("my_couple_id").then(({ data }) => {
      if (active) {
        setCoupleId(typeof data === "string" ? data : null);
        setCoupleReady(true);
      }
    });
    return () => {
      active = false;
    };
  }, [accountUser, accountOpen]);
  useEffect(() => {
    if (accountUser) void restoreNativeNotifications();
  }, [accountUser]);
  useEffect(() => {
    const openTalk = () => setCurrentTab("talk");
    window.addEventListener("tired-off:open-talk", openTalk);
    return () => window.removeEventListener("tired-off:open-talk", openTalk);
  }, []);
  useEffect(() => {
    if (!accountUser || !coupleId || !coupleReady) return;
    const key = `tired-off-play-intro-seen:${accountUser.id}`;
    if (localStorage.getItem(key) !== "yes") setPlayIntroOpen(true);
  }, [accountUser, coupleId, coupleReady]);
  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 60000);
    return () => window.clearInterval(timer);
  }, []);
  useEffect(() => {
    const update = () => setIsOnline(navigator.onLine);
    update();
    window.addEventListener("online", update);
    window.addEventListener("offline", update);
    return () => { window.removeEventListener("online", update); window.removeEventListener("offline", update); };
  }, []);
  useEffect(() => {
    if (
      showWelcome === false &&
      localStorage.getItem("tired-off-rules-seen") !== "yes"
    )
      setRulesOpen(true);
  }, [showWelcome]);
  useEffect(() => {
    if (ready)
      localStorage.setItem(
        "tired-off-state",
        JSON.stringify({
          a,
          b,
          history,
          rewardRound,
          hall,
          customRewards,
          hiddenRewards,
          activeCardIds,
          customCards,
          activeMetricIds,
          pendingMetricIds,
          customMetrics,
          scorecardWeek,
        }),
      );
  }, [
    a,
    b,
    history,
    rewardRound,
    hall,
    customRewards,
    hiddenRewards,
    activeCardIds,
    customCards,
    activeMetricIds,
    pendingMetricIds,
    customMetrics,
    scorecardWeek,
    ready,
  ]);
  const allCards = [...cardLibrary, ...customCards];
  const activeCards = allCards.filter((c) => activeCardIds.includes(c.id));
  const allMetrics = [
    ...metricLibrary,
    ...customMetrics.map(customMetricDefinition),
  ];
  const activeMetrics = activeMetricIds
    .map((id) => allMetrics.find((m) => m.id === id))
    .filter((m): m is MetricDefinition => Boolean(m));
  const editingMetricIds = pendingMetricIds || activeMetricIds;
  const optionalCount = editingMetricIds.filter(
    (id) => !coreMetricIds.includes(id),
  ).length;
  const scoreA = score(a, activeCards, activeMetrics),
    scoreB = score(b, activeCards, activeMetrics),
    margin = Math.abs(scoreA - scoreB),
    winner =
      margin <= 2
        ? "Draw"
        : scoreA > scoreB
          ? a.name || "Player 1"
          : b.name || "Player 2";
  const stats = useMemo(
    () =>
      [a.name || "Player 1", b.name || "Player 2"].map((name) => {
        const played = history.filter(
          (r) => r.a.name === name || r.b.name === name,
        );
        return {
          name,
          wins: history.filter((r) => r.winner === name).length,
          average: Math.round(
            played.reduce(
              (sum, r) => sum + (r.a.name === name ? r.a.score : r.b.score),
              0,
            ) / Math.max(1, played.length),
          ),
        };
      }),
    [history, a.name, b.name],
  );
  const thisWeek = weekKey(now);
  const weeklyResults = history.filter(
    (r) => weekKey(new Date(r.date)) === thisWeek,
  );

  async function saveAccountName() {
    if (!accountUser || !accountName.trim()) return;
    setAccountBusy(true);
    setAccountMessage("");
    const displayName = accountName.trim().slice(0, 40);
    const { error } = await supabase.auth.updateUser({ data: { display_name: displayName } });
    if (!error) await supabase.from("profiles").update({ display_name: displayName }).eq("id", accountUser.id);
    if (error) setAccountMessage("That name didn’t save. Check your connection and try again.");
    else {
      setAccountUser({ ...accountUser, user_metadata: { ...accountUser.user_metadata, display_name: displayName } });
      setAccountMessage("Display name saved.");
    }
    setAccountBusy(false);
  }

  async function runDangerAction() {
    if (!dangerAction) return;
    setAccountBusy(true);
    setAccountMessage("");
    const rpc = dangerAction === "unpair" ? "leave_tired_off_couple" : "delete_my_tired_off_account";
    const { error } = await supabase.rpc(rpc);
    if (error) {
      setAccountMessage("Account controls need their one-time database update before this can be used.");
    } else if (dangerAction === "unpair") {
      setCoupleId(null);
      setAccountMessage("You have been safely unpaired. Your partner will need a new invitation to reconnect.");
      setCurrentTab("battle");
    } else {
      await supabase.auth.signOut();
      setAccountUser(null);
      setCoupleId(null);
      setSettingsOpen(false);
      setAccountOpen(true);
    }
    setDangerAction(null);
    setAccountBusy(false);
  }
  const weeklyNames = [a.name || "Player 1", b.name || "Player 2"];
  const statsFor = (results: Result[]) =>
    weeklyNames.map((name) => ({
      name,
      crowns: results.filter((r) => r.winner === name).length,
      total: results.reduce(
        (sum, r) =>
          sum +
          (r.a.name === name ? r.a.score : r.b.name === name ? r.b.score : 0),
        0,
      ),
    }));
  const championFor = (results: Result[]) => {
    const s = statsFor(results);
    return s[0].crowns === s[1].crowns
      ? s[0].total === s[1].total
        ? "Joint champions"
        : s[0].total > s[1].total
          ? s[0].name
          : s[1].name
      : s[0].crowns > s[1].crowns
        ? s[0].name
        : s[1].name;
  };
  const weeklyStats = statsFor(weeklyResults);
  const weeklyChampion = championFor(weeklyResults);
  const closedWeeks = [
    ...new Set(history.map((r) => weekKey(new Date(r.date)))),
  ]
    .filter(
      (key) => weekUnlock(key) <= now && !hall.some((x) => x.week === key),
    )
    .sort()
    .reverse();
  const availableWeek = rewardRound?.week || closedWeeks[0];
  const availableResults = availableWeek
    ? history.filter((r) => weekKey(new Date(r.date)) === availableWeek)
    : [];
  const availableChampion = availableResults.length
    ? championFor(availableResults)
    : weeklyChampion;
  const nextUnlock = weekUnlock(thisWeek);
  const countdownDays = Math.max(
    0,
    Math.ceil((nextUnlock.getTime() - now.getTime()) / 86400000),
  );
  const rewardPool = [...starterRewards, ...customRewards].filter(
    (r) => !hiddenRewards.includes(r),
  );
  function saveResult() {
    const r: Result = {
      id: crypto.randomUUID(),
      date: new Date().toISOString(),
      a: { name: a.name || "Player 1", score: scoreA },
      b: { name: b.name || "Player 2", score: scoreB },
      winner,
      margin,
    };
    setHistory((items) => [r, ...items].slice(0, 100));
    setSaved(true);
    window.setTimeout(() => setSaved(false), 1800);
  }
  function resetDay() {
    setA(defaultPlayer(a.name || "Joe"));
    setB(defaultPlayer(b.name || "Partner"));
    setSaved(false);
  }
  function revealRewards() {
    if (!availableWeek || !availableResults.length) return;
    setRewardRound({
      week: availableWeek,
      champion: availableChampion,
      cards: sampleRewards(rewardPool),
      picked: null,
      swapped: false,
    });
  }
  function swapReward() {
    if (!rewardRound || rewardRound.swapped) return;
    setRewardRound({
      ...rewardRound,
      cards: sampleRewards(rewardPool.filter((r) => r !== rewardRound.picked)),
      picked: null,
      swapped: true,
    });
  }
  function completeReward() {
    if (!rewardRound?.picked) return;
    setHall((items) => [
      {
        id: crypto.randomUUID(),
        week: rewardRound.week,
        champion: rewardRound.champion,
        reward: rewardRound.picked!,
        completedAt: new Date().toISOString(),
      },
      ...items,
    ]);
    setRewardRound(null);
  }
  function addReward() {
    const value = newReward.trim();
    if (!value || customRewards.includes(value)) return;
    setCustomRewards((items) => [...items, value]);
    setNewReward("");
  }
  function toggleDeckCard(id: string) {
    if (weeklyResults.length) {
      setDeckMessage(
        "This week’s deck is locked after the first saved result.",
      );
      return;
    }
    const active = activeCardIds.includes(id);
    if (active && activeCardIds.length <= 8) {
      setDeckMessage("Keep at least 8 cards in your shared deck.");
      return;
    }
    if (!active && activeCardIds.length >= 12) {
      setDeckMessage("Your deck can hold up to 12 cards.");
      return;
    }
    setActiveCardIds((items) =>
      active ? items.filter((x) => x !== id) : [...items, id],
    );
    setDeckMessage("");
  }
  function addCustomCard() {
    const title = cardTitle.trim();
    if (!title) return;
    const card: ExhaustionCard = {
      id: `custom-${crypto.randomUUID()}`,
      emoji: cardEmoji.trim() || "😵",
      title,
      points: cardPoints,
      custom: true,
    };
    setCustomCards((items) => [...items, card]);
    if (!weeklyResults.length && activeCardIds.length < 12)
      setActiveCardIds((items) => [...items, card.id]);
    setCardTitle("");
    setCardEmoji("😵");
    setCardPoints(10);
    setDeckMessage(
      weeklyResults.length
        ? "Custom card saved for next week’s deck."
        : activeCardIds.length >= 12
          ? "Custom card saved. Remove another card to activate it."
          : "",
    );
  }
  function toggleMetric(id: string) {
    if (coreMetricIds.includes(id)) return;
    const current = pendingMetricIds || activeMetricIds;
    const selected = current.includes(id);
    if (
      !selected &&
      current.filter((x) => !coreMetricIds.includes(x)).length >= 6
    ) {
      setScorecardMessage(
        "Choose up to six extras alongside the four core measurements.",
      );
      return;
    }
    setPendingMetricIds(
      selected ? current.filter((x) => x !== id) : [...current, id],
    );
    setScorecardMessage(
      "Saved for next Monday. This week’s scorecard stays unchanged.",
    );
  }
  function addCustomMetric() {
    const label = metricLabel.trim();
    if (!label) return;
    const metric: CustomMetric = {
      id: `metric-${crypto.randomUUID()}`,
      label,
      emoji: metricEmoji.trim() || "⚡",
      unit: metricUnit,
      impact: metricImpact,
    };
    setCustomMetrics((items) => [...items, metric]);
    const current = pendingMetricIds || activeMetricIds;
    if (current.filter((x) => !coreMetricIds.includes(x)).length < 6) {
      setPendingMetricIds([...current, metric.id]);
      setScorecardMessage(
        "Custom measurement added to next week’s shared scorecard.",
      );
    } else
      setScorecardMessage(
        "Custom measurement saved. Remove another extra to add it next week.",
      );
    setMetricLabel("");
    setMetricEmoji("⚡");
  }
  useEffect(() => {
    const context = (
      document as Document & {
        modelContext?: {
          registerTool?: (
            tool: unknown,
            options?: { signal?: AbortSignal },
          ) => void | Promise<void>;
        };
      }
    ).modelContext;
    if (!context?.registerTool) return;
    const lifecycle = new AbortController();
    const reg = (tool: unknown) =>
      Promise.resolve(
        context.registerTool?.(tool, { signal: lifecycle.signal }),
      ).catch(() => undefined);
    reg({
      name: "get_tiredness_scores",
      title: "Get tiredness scores",
      description: "Read the current tiredness scores and today's leader.",
      inputSchema: {
        type: "object",
        properties: {},
        additionalProperties: false,
      },
      annotations: { readOnlyHint: true, untrustedContentHint: false },
      execute: () => ({
        playerOne: { name: a.name, score: scoreA },
        playerTwo: { name: b.name, score: scoreB },
        winner,
        margin,
      }),
    });
    reg({
      name: "save_tiredness_result",
      title: "Save today's result",
      description: "Save the current battle to championship history.",
      inputSchema: {
        type: "object",
        properties: {},
        additionalProperties: false,
      },
      annotations: { readOnlyHint: false, untrustedContentHint: false },
      execute: () => {
        saveResult();
        return { saved: true, winner, margin };
      },
    });
    return () => lifecycle.abort();
  }, [a, b, scoreA, scoreB, winner, margin]);
  const achievements = [
    {
      icon: "🌙",
      title: "Midnight hero",
      text: "Record a truly exhausting day",
      unlocked: history.some((r) => Math.max(r.a.score, r.b.score) >= 60),
    },
    {
      icon: "🔥",
      title: "Running on fumes",
      text: "Reach a score of 85",
      unlocked: history.some((r) => Math.max(r.a.score, r.b.score) >= 85),
    },
    {
      icon: "🏆",
      title: "Hat-trick",
      text: "Win three battles",
      unlocked: stats.some((s) => s.wins >= 3),
    },
    {
      icon: "🤝",
      title: "Equally exhausted",
      text: "Finish in a dead heat",
      unlocked: history.some((r) => r.winner === "Draw"),
    },
  ];
  if (showWelcome === null || !accountReady)
    return <div className="launch-blank" />;
  if (showWelcome)
    return (
      <main className="welcome-screen">
        <section className="welcome-card">
          <img
            className="welcome-main-logo"
            src="/tired-off-logo.png"
            alt="Tired-Off: two sleepy pillows facing off"
          />
          <span className="eyebrow">THE RELATIONSHIP DEBATE</span>
          <h1>It&apos;s time to settle it.</h1>
          <p className="welcome-question">
            Who is actually
            <br />
            <strong>more tired?</strong>
          </p>
          <p className="welcome-copy">
            Compare the sleep, work, wake-ups, childcare and chaos. Then let
            Tired-Off decide.
          </p>
          <Button
            size="lg"
            className="welcome-button"
            onClick={() => {
              localStorage.setItem("tired-off-welcomed", "yes");
              setShowWelcome(false);
            }}
          >
            Start the Tired-Off <ArrowRight />
          </Button>
          <div className="welcome-foot">
            <Heart />
            Made for couples who are both definitely tired
          </div>
        </section>
      </main>
    );
  if (accountOpen)
    return (
      <AuthPanel
        user={accountUser}
        onContinue={(user) => {
          const display = String(
            user.user_metadata?.display_name || user.email?.split("@")[0] || "",
          );
          if (display && a.name === "Joe") setA({ ...a, name: display });
          localStorage.removeItem("tired-off-auth-skipped");
          setAccountOpen(false);
        }}
        onGuest={() => {
          localStorage.setItem("tired-off-auth-skipped", "yes");
          setAccountOpen(false);
        }}
        onSignOut={async () => {
          await supabase.auth.signOut();
          setAccountUser(null);
        }}
      />
    );
  return (
    <main>
      {!isOnline && <div className="offline-banner" role="status">📵 You’re offline. Your unfinished sliders stay on this phone and will sync when you reconnect.</div>}
      <header className="app-header">
        <div className="brand-mark">
          <Moon />
        </div>
        <div>
          <h1>Tired-Off</h1>
          <p>Who&apos;s more tired?</p>
        </div>
        <div className="header-actions">
          <button
            className="account-button"
            type="button"
            onClick={() => setAccountOpen(true)}
          >
            <UserRound />
            {accountUser ? "Account" : "Sign in"}
          </button>
          <button
            className="rules-button"
            type="button"
            onClick={() => setRulesOpen(true)}
          >
            <HelpCircle />
            How it works
          </button>
          <button
            className="settings-button"
            type="button"
            onClick={() => setSettingsOpen(true)}
            aria-label="Settings"
          >
            <Settings />
            Settings
          </button>
        </div>
      </header>
      <Dialog open={settingsOpen} onOpenChange={setSettingsOpen}>
        <DialogContent className="settings-dialog">
          <DialogHeader>
            <span className="settings-icon"><Settings /></span>
            <DialogTitle>Settings</DialogTitle>
            <DialogDescription>
              Make Tired-Off look comfortable on your phone. Your partner can choose their own theme.
            </DialogDescription>
          </DialogHeader>
          <section>
            <h3>Choose your theme</h3>
            <div className="theme-grid">
              {([
                ["midnight", "🌙", "Midnight", "The original dark-blue look"],
                ["daylight", "☀️", "Daylight", "Bright, clean and easy to read"],
                ["pink", "🩷", "Pink Pillow", "Pink, plum and soft purple"],
                ["lazy", "😴", "Lazy Sunday", "Warm, cosy and extra sleepy"],
              ] as const).map(([id, emoji, name, description]) => (
                <button
                  type="button"
                  key={id}
                  className={theme === id ? `theme-choice ${id} selected` : `theme-choice ${id}`}
                  onClick={() => setTheme(id)}
                >
                  <span>{emoji}</span>
                  <strong>{name}</strong>
                  <small>{description}</small>
                  <b>{theme === id ? "Selected ✓" : "Choose"}</b>
                </button>
              ))}
            </div>
          </section>
          <section className="settings-section">
            <h3>How do you play?</h3>
            <p className="settings-note">This only changes the tone of your own app. It never changes anyone’s score.</p>
            <div className="play-style-picker">
              {([
                ["fair", "⚖️", "Keep it fair", "Honest scores and proper bragging rights"],
                ["funny", "😂", "Keep it funny", "Big reactions and harmless household banter"],
                ["survival", "🏳️", "Relationship survival", "Concede gracefully when peace must prevail"],
              ] as const).map(([id, emoji, title, copy]) => (
                <button type="button" key={id} className={playStyle === id ? "play-style-choice selected" : "play-style-choice"} onClick={() => setPlayStyle(id)}>
                  <span>{emoji}</span><strong>{title}</strong><small>{copy}</small>
                </button>
              ))}
            </div>
            <Button variant="outline" onClick={() => { setSettingsOpen(false); setPlayIntroOpen(true); }}>
              Replay the welcome guide
            </Button>
          </section>
          <section className="settings-section">
            <h3>Comfort and accessibility</h3>
            <label className="setting-toggle"><span><strong>Larger text</strong><small>Make everyday labels and results easier to read.</small></span><input type="checkbox" checked={largeText} onChange={(e) => setLargeText(e.target.checked)} /></label>
            <label className="setting-toggle"><span><strong>Reduce movement</strong><small>Turns off spinning and sliding effects.</small></span><input type="checkbox" checked={reducedMotion} onChange={(e) => setReducedMotion(e.target.checked)} /></label>
          </section>
          {accountUser && (
            <section className="settings-section account-controls">
              <h3>Account and partner</h3>
              <label className="account-name-field">Display name<input value={accountName} maxLength={40} onChange={(e) => setAccountName(e.target.value)} /></label>
              <Button variant="outline" disabled={accountBusy || !accountName.trim()} onClick={saveAccountName}>Save display name</Button>
              <div className="danger-buttons">
                {coupleId && <Button variant="outline" disabled={accountBusy} onClick={() => setDangerAction("unpair")}>Unpair from partner</Button>}
                <Button variant="outline" disabled={accountBusy} onClick={() => setDangerAction("delete")}>Delete my account</Button>
              </div>
              {accountMessage && <p className="account-control-message" aria-live="polite">{accountMessage}</p>}
            </section>
          )}
          <p className="settings-note">Closed-app notifications, sounds and health connections will arrive with the downloadable app.</p>
          <DialogFooter>
            <DialogClose asChild><Button size="lg">Save my look</Button></DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <Dialog open={dangerAction !== null} onOpenChange={(open) => !open && setDangerAction(null)}>
        <DialogContent className="danger-dialog">
          <DialogHeader>
            <span className="danger-icon">{dangerAction === "delete" ? "🗑️" : "💔"}</span>
            <DialogTitle>{dangerAction === "delete" ? "Delete your Tired-Off account?" : "Unpair from your partner?"}</DialogTitle>
            <DialogDescription>
              {dangerAction === "delete"
                ? "This permanently removes your login and your Tired-Off data. It cannot be undone."
                : "You will leave this couple. Your partner keeps their account, but you will both need a new invitation to pair again."}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline">Cancel</Button></DialogClose>
            <Button disabled={accountBusy} onClick={runDangerAction}>{accountBusy ? "Please wait…" : dangerAction === "delete" ? "Permanently delete" : "Yes, unpair me"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <Dialog
        open={playIntroOpen}
        onOpenChange={(open) => {
          setPlayIntroOpen(open);
          if (!open && accountUser)
            localStorage.setItem(`tired-off-play-intro-seen:${accountUser.id}`, "yes");
        }}
      >
        <DialogContent className="play-intro-dialog">
          <DialogHeader>
            <span className="rules-moon">😴</span>
            <DialogTitle>Welcome to competitive exhaustion</DialogTitle>
            <DialogDescription>
              The app created to settle the oldest argument in any relationship.
            </DialogDescription>
          </DialogHeader>
          <p className="play-intro-argument">
            “You think you&apos;re tired? <strong>I&apos;m more tired than you.</strong>”
          </p>
          <p className="play-intro-copy">
            Play it seriously. Play it for laughs. Or carefully adjust your
            score until it confirms what you already knew.
          </p>
          <div className="play-styles">
            <div><span>⚖️</span><strong>Keep it fair</strong><small>Honest scores and serious bragging rights.</small></div>
            <div><span>😂</span><strong>Keep it funny</strong><small>Dramatic scoring and plenty of banter.</small></div>
            <div><span>🏳️</span><strong>Relationship survival</strong><small>Concede the crown whenever necessary.</small></div>
          </div>
          <div className="first-week-guide">
            <strong>Your first week in four sleepy steps</strong>
            <ol>
              <li><span>1</span><p><b>Set the rules together</b>Choose next week’s shared measurements and exhaustion cards.</p></li>
              <li><span>2</span><p><b>Check in privately</b>Move your sliders during the day, then lock in when you are ready.</p></li>
              <li><span>3</span><p><b>Reveal the evidence</b>Once you both submit, compare every answer and award the daily crown.</p></li>
              <li><span>4</span><p><b>Collect Sunday’s reward</b>The weekly champion chooses a reward at 7:00 pm.</p></li>
            </ol>
          </div>
          <p className="play-intro-note">
            Customise your shared scorecard, exhaustion cards and weekly rewards
            to suit your relationship. There is no correct way to be tired.
          </p>
          <DialogFooter>
            <DialogClose asChild>
              <Button size="lg">Right then—who&apos;s more tired?</Button>
            </DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <Dialog
        open={rulesOpen}
        onOpenChange={(open) => {
          setRulesOpen(open);
          if (!open) localStorage.setItem("tired-off-rules-seen", "yes");
        }}
      >
        <DialogContent className="rules-dialog">
          <DialogHeader>
            <span className="rules-moon">🌙</span>
            <DialogTitle>How Tired-Off works</DialogTitle>
          <DialogDescription>
              The official rules of competitive exhaustion.
            </DialogDescription>
          </DialogHeader>
          <section className="rules-play-your-way">
            <h3>Play it your way</h3>
            <p>
              Keep it fair, keep it funny, or enter relationship-survival mode.
              You can customise your measurements, exhaustion cards and rewards
              together—just agree what counts before the week locks.
            </p>
            <div><span>⚖️ Honest</span><span>😂 Dramatic</span><span>🏳️ Strategic surrender</span></div>
          </section>
          <ol className="rules-list">
            <li>
              <b>Check in daily.</b>
              <span>
                Score the measurements on your shared scorecard, then add any
                exhaustion cards that apply.
              </span>
            </li>
            <li>
              <b>Use one shared scorecard.</b>
              <span>
                Both partners use exactly the same measurements, so the contest
                stays fair.
              </span>
            </li>
            <li>
              <b>Four essentials stay put.</b>
              <span>
                Hours slept, hours worked, night wake-ups and minutes awake
                overnight are always included.
              </span>
            </li>
            <li>
              <b>Agree your extras.</b>
              <span>
                Add up to six optional or custom measurements that suit your
                real life—childcare, chores, commuting or anything else.
              </span>
            </li>
            <li>
              <b>Locked Monday to Sunday.</b>
              <span>
                The active scorecard cannot change during the week. Any edits
                are queued and automatically start the following Monday.
              </span>
            </li>
            <li>
              <b>No peeking.</b>
              <span>
                In couple mode, your answers stay hidden until you&apos;ve both
                locked in. Then both partners can compare the sliders and cards.
              </span>
            </li>
            <li>
              <b>Send a Tired Talk.</b>
              <span>Pick a quick message for your partner. Only the two of you can see your conversation. Phone alerts arrive while Tired-Off is running if you enable notifications.</span>
            </li>
            <li>
              <b>Win the crown.</b>
              <span>The higher tiredness score earns one daily crown.</span>
            </li>
            <li>
              <b>Concede gracefully.</b>
              <span>
                Tired because you chose the fun? Tap “You win today” and hand
                your partner the crown. A concession is final for that day.
              </span>
            </li>
            <li>
              <b>Win the week.</b>
              <span>
                Most crowns by Sunday takes the title. Combined tiredness points
                settle a tie.
              </span>
            </li>
            <li>
              <b>Sunday reveal.</b>
              <span>Rewards unlock at 7:00 pm in your local time.</span>
            </li>
            <li>
              <b>Choose your prize.</b>
              <span>
                The weekly champion picks one of three mystery rewards, with one
                friendly swap allowed.
              </span>
            </li>
            <li>
              <b>Enjoy it next week.</b>
              <span>Complete the reward and add it to your Hall of Rest.</span>
            </li>
          </ol>
          <p className="fair-play">
            No exaggerating, tactical yawning or mysteriously forgetting the
            night feed.
          </p>
          <p className="health-note">
            Tired-Off is just for fun, not a medical fatigue assessment.
          </p>
          <DialogFooter>
            <DialogClose asChild>
              <Button size="lg">Got it—let the tiredness begin</Button>
            </DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <Dialog open={deckOpen} onOpenChange={setDeckOpen}>
        <DialogContent className="deck-dialog">
          <DialogHeader>
            <span className="deck-icon">
              <Layers3 />
            </span>
            <DialogTitle>Build your Exhaustion Deck</DialogTitle>
            <DialogDescription>
              Choose 8–12 cards for both partners. Positive points add
              tiredness; recovery cards take it away.
            </DialogDescription>
          </DialogHeader>
          {weeklyResults.length > 0 && (
            <div className="deck-lock">
              <LockKeyhole />
              This week&apos;s deck is locked because a result has already been
              saved. You can still create cards for next week.
            </div>
          )}
          <div className="deck-count">
            <strong>{activeCardIds.length}/12 selected</strong>
            <span>Shared by both players</span>
          </div>
          <div className="deck-grid">
            {allCards.map((c) => {
              const selected = activeCardIds.includes(c.id);
              return (
                <button
                  type="button"
                  aria-pressed={selected}
                  className={selected ? "deck-card selected" : "deck-card"}
                  onClick={() => toggleDeckCard(c.id)}
                  key={c.id}
                >
                  <span>{c.emoji}</span>
                  <div>
                    <strong>{c.title}</strong>
                    <small>
                      {c.points > 0 ? "+" : ""}
                      {c.points} points{c.custom ? " · Custom" : ""}
                    </small>
                  </div>
                  <i>{selected ? "✓" : "＋"}</i>
                </button>
              );
            })}
          </div>
          {deckMessage && <p className="deck-message">{deckMessage}</p>}
          <div className="custom-card-maker">
            <h3>Create your own card</h3>
            <div className="custom-card-fields">
              <input
                className="emoji-input"
                value={cardEmoji}
                onChange={(e) => setCardEmoji(e.target.value)}
                maxLength={4}
                aria-label="Card emoji"
              />
              <input
                value={cardTitle}
                onChange={(e) => setCardTitle(e.target.value)}
                placeholder="e.g. Did the school run"
                aria-label="Card title"
              />
            </div>
            <div className="impact-options">
              {[-15, -10, -5, 5, 10, 15].map((points) => (
                <button
                  type="button"
                  className={cardPoints === points ? "impact active" : "impact"}
                  onClick={() => setCardPoints(points)}
                  key={points}
                >
                  {points > 0 ? "+" : ""}
                  {points}
                </button>
              ))}
            </div>
            <Button onClick={addCustomCard}>
              <Plus />
              Add custom card
            </Button>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button size="lg">Save deck</Button>
            </DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <Dialog open={scorecardOpen} onOpenChange={setScorecardOpen}>
        <DialogContent className="scorecard-dialog">
          <DialogHeader>
            <span className="scorecard-icon">
              <SlidersHorizontal />
            </span>
            <DialogTitle>Your shared scorecard</DialogTitle>
            <DialogDescription>
              Choose what you both track. Changes made here begin next Monday.
            </DialogDescription>
          </DialogHeader>
          <div className="scorecard-lock">
            <LockKeyhole />
            <div>
              <strong>This week is locked</strong>
              <span>
                Your current scorecard stays fair and unchanged until Sunday
                ends.
              </span>
            </div>
          </div>
          <section className="scorecard-section">
            <div className="scorecard-heading">
              <div>
                <h3>Core measurements</h3>
                <p>These four always stay on.</p>
              </div>
              <span>4 fixed</span>
            </div>
            <div className="metric-picker core">
              {metricLibrary
                .filter((m) => m.core)
                .map((m) => (
                  <div
                    className="metric-choice selected core-choice"
                    key={m.id}
                  >
                    <m.icon />
                    <span>
                      <strong>{m.label}</strong>
                      <small>Always included</small>
                    </span>
                    <i>✓</i>
                  </div>
                ))}
            </div>
          </section>
          <section className="scorecard-section">
            <div className="scorecard-heading">
              <div>
                <h3>Choose your extras</h3>
                <p>Add up to six for next week.</p>
              </div>
              <span>{optionalCount}/6</span>
            </div>
            <div className="metric-picker">
              {allMetrics
                .filter((m) => !m.core)
                .map((m) => {
                  const selected = editingMetricIds.includes(m.id);
                  return (
                    <button
                      type="button"
                      className={
                        selected ? "metric-choice selected" : "metric-choice"
                      }
                      onClick={() => toggleMetric(m.id)}
                      key={m.id}
                    >
                      {m.emoji ? <b>{m.emoji}</b> : <m.icon />}
                      <span>
                        <strong>{m.label}</strong>
                        <small>
                          {selected ? "On next week’s card" : "Tap to add"}
                        </small>
                      </span>
                      <i>{selected ? "✓" : "＋"}</i>
                    </button>
                  );
                })}
            </div>
          </section>
          <section className="custom-metric-maker">
            <h3>Create your own measurement</h3>
            <p>
              Give it a name, how it is measured and how strongly it should
              affect the score.
            </p>
            <div className="custom-metric-name">
              <input
                className="emoji-input"
                value={metricEmoji}
                onChange={(e) => setMetricEmoji(e.target.value)}
                maxLength={4}
                aria-label="Measurement emoji"
              />
              <input
                value={metricLabel}
                onChange={(e) => setMetricLabel(e.target.value)}
                placeholder="e.g. School runs"
                aria-label="Measurement name"
              />
            </div>
            <div className="select-row">
              <label>
                Measure in
                <select
                  value={metricUnit}
                  onChange={(e) =>
                    setMetricUnit(e.target.value as CustomMetric["unit"])
                  }
                >
                  <option value="hours">Hours</option>
                  <option value="minutes">Minutes</option>
                  <option value="count">Number of times</option>
                  <option value="rating">Rating out of 5</option>
                </select>
              </label>
              <label>
                Score impact
                <select
                  value={metricImpact}
                  onChange={(e) =>
                    setMetricImpact(e.target.value as CustomMetric["impact"])
                  }
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </label>
            </div>
            <Button onClick={addCustomMetric}>
              <Plus />
              Add for next week
            </Button>
          </section>
          {scorecardMessage && (
            <p className="scorecard-message">{scorecardMessage}</p>
          )}
          <DialogFooter>
            <DialogClose asChild>
              <Button size="lg">Done</Button>
            </DialogClose>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <Tabs value={currentTab} onValueChange={setCurrentTab} className="app-shell">
        <TabsList className="nav-tabs">
          <TabsTrigger value="battle">
            <Crown />
            Today
          </TabsTrigger>
          <TabsTrigger value="championship">
            <Trophy />
            Championship
          </TabsTrigger>
          <TabsTrigger value="rewards">
            <Gift />
            Rewards
          </TabsTrigger>
          {accountUser && coupleId && <TabsTrigger value="talk">
            <MessageCircle />
            Talk{talkUnread > 0 && <span className="talk-tab-count">{talkUnread}</span>}
          </TabsTrigger>}
          <TabsTrigger value="achievements">
            <Award />
            Achievements
          </TabsTrigger>
        </TabsList>
        <TabsContent value="battle">
          {accountUser ? (
            !coupleReady ? (
              <section className="waiting-card">
                <Moon />
                <h2>Loading your shared battle…</h2>
              </section>
            ) : coupleId ? (
              <OnlineBattle user={accountUser} playStyle={playStyle} />
            ) : (
              <section className="waiting-card">
                <Users />
                <span className="eyebrow">PAIR WITH YOUR PARTNER</span>
                <h2>Your private battle is nearly ready</h2>
                <p>Open your account and create or join a couple first.</p>
                <Button onClick={() => setAccountOpen(true)}>
                  Open account
                </Button>
              </section>
            )
          ) : (
            <>
              <section className="verdict-card">
                <div className="crown">
                  <Crown />
                </div>
                <div>
                  <span className="eyebrow">TODAY&apos;S TIRED-OFF</span>
                  <h2>
                    {winner === "Draw"
                      ? "It’s a dead heat!"
                      : `${winner} takes the crown`}
                  </h2>
                  <p>
                    {winner === "Draw"
                      ? "You're equally entitled to complain today."
                      : `${margin} tired-points ahead. ${margin >= 20 ? "This one isn't even close." : margin >= 10 ? "A convincing victory in exhaustion." : "A narrow household victory."}`}
                  </p>
                </div>
                <div className="verdict-actions">
                  <Button size="lg" onClick={saveResult}>
                    <Save />
                    {saved ? "Saved!" : "Save result"}
                  </Button>
                  <Button size="lg" variant="outline" onClick={resetDay}>
                    <RotateCcw />
                    Reset
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    onClick={() => setDeckOpen(true)}
                  >
                    <Layers3 />
                    Edit deck
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    onClick={() => setScorecardOpen(true)}
                  >
                    <SlidersHorizontal />
                    Scorecard
                  </Button>
                </div>
              </section>
              <div className="players-grid">
                <PlayerCard
                  player={a}
                  setPlayer={setA}
                  colour="coral"
                  cards={activeCards}
                  metrics={activeMetrics}
                />
                <PlayerCard
                  player={b}
                  setPlayer={setB}
                  colour="blue"
                  cards={activeCards}
                  metrics={activeMetrics}
                />
              </div>
            </>
          )}
        </TabsContent>
        <TabsContent value="championship">
          {accountUser && coupleId ? (
            <OnlineChampionship />
          ) : (
            <section className="page-card">
              <span className="eyebrow">THIS MONTH</span>
              <h2>The tiredness championship</h2>
              <div className="leaderboard">
                {[...stats]
                  .sort((x, y) => y.wins - x.wins)
                  .map((s, i) => (
                    <div className="leader" key={s.name}>
                      <span className="place">{i === 0 ? "👑" : "#2"}</span>
                      <div>
                        <strong>{s.name}</strong>
                        <small>
                          {s.wins} wins · Average {s.average}/100
                        </small>
                      </div>
                      <b>{s.wins}</b>
                    </div>
                  ))}
              </div>
              <h3>Recent battles</h3>
              {history.length === 0 ? (
                <div className="empty">
                  <Moon />
                  <p>
                    No results yet. Finish today&apos;s battle to start the
                    championship.
                  </p>
                </div>
              ) : (
                <div className="history-list">
                  {history.map((r) => (
                    <div key={r.id}>
                      <span>
                        {new Date(r.date).toLocaleDateString("en-GB", {
                          day: "numeric",
                          month: "short",
                        })}
                      </span>
                      <strong>
                        {r.winner === "Draw" ? "Draw" : `${r.winner} won`}
                      </strong>
                      <small>
                        {r.a.name} {r.a.score} · {r.b.score} {r.b.name}
                      </small>
                    </div>
                  ))}
                </div>
              )}
            </section>
          )}
        </TabsContent>
        <TabsContent value="rewards">
          {accountUser && coupleId ? (
            <OnlineRewards user={accountUser} />
          ) : (
            <section className="page-card rewards-page">
              <span className="eyebrow">THE REST REWARDS</span>
              <h2>Victory is tiring. You&apos;ve earned this.</h2>
              <p className="section-copy">
                Daily wins earn crowns. On Sunday, the week&apos;s most tired
                person chooses one of three mystery rewards to use the following
                week.
              </p>
              <div className="weekly-score">
                {weeklyStats.map((s, i) => (
                  <div
                    className={
                      weeklyChampion === s.name && weeklyResults.length
                        ? "weekly-player leading"
                        : "weekly-player"
                    }
                    key={s.name}
                  >
                    <span>{i === 0 ? "😴" : "🥱"}</span>
                    <div>
                      <strong>{s.name}</strong>
                      <small>{s.total} tired-points this week</small>
                    </div>
                    <b>
                      {s.crowns}
                      <small> crowns</small>
                    </b>
                  </div>
                ))}
              </div>
              {rewardRound ? (
                <div className="reward-game">
                  <p className="reward-winner">
                    <Crown />
                    {rewardRound.champion}&apos;s reward
                  </p>
                  <div className="reward-cards">
                    {rewardRound.cards.map((reward, i) => (
                      <button
                        type="button"
                        onClick={() =>
                          setRewardRound({ ...rewardRound, picked: reward })
                        }
                        className={
                          rewardRound.picked === reward
                            ? "reward-card picked"
                            : "reward-card"
                        }
                        key={reward}
                      >
                        <span>
                          {rewardRound.picked === reward
                            ? "✨"
                            : i === 0
                              ? "🌙"
                              : i === 1
                                ? "💆"
                                : "☕"}
                        </span>
                        <strong>{reward}</strong>
                        <small>
                          {rewardRound.picked === reward
                            ? "Chosen reward"
                            : "Tap to choose"}
                        </small>
                      </button>
                    ))}
                  </div>
                  {rewardRound.picked && (
                    <div className="reward-actions">
                      <Button onClick={completeReward}>
                        <CheckCircle2 />
                        Mark as enjoyed
                      </Button>
                      <Button
                        variant="outline"
                        disabled={rewardRound.swapped}
                        onClick={swapReward}
                      >
                        <Shuffle />
                        {rewardRound.swapped ? "Swap used" : "Use one swap"}
                      </Button>
                    </div>
                  )}
                </div>
              ) : availableWeek ? (
                <div className="reward-reveal">
                  <div className="reward-crown">👑</div>
                  <h3>{availableChampion} won the week</h3>
                  <p>
                    The Sunday reveal is ready. Pick from three mystery
                    rewards—this prize stays available until it&apos;s claimed.
                  </p>
                  <Button size="lg" onClick={revealRewards}>
                    <Gift />
                    Reveal reward cards
                  </Button>
                </div>
              ) : (
                <div className="reward-locked">
                  <LockKeyhole />
                  <div>
                    <span className="eyebrow">REVEAL LOCKED</span>
                    <h3>Sunday at 7:00 pm</h3>
                    <p>
                      {weeklyResults.length
                        ? `${weeklyChampion} is currently leading. ${countdownDays} ${countdownDays === 1 ? "day" : "days"} until the cards unlock.`
                        : "Save your first result this week to begin the race for the Rest Reward."}
                    </p>
                  </div>
                </div>
              )}
              <div className="reward-settings">
                <h3>Your reward deck</h3>
                <p>
                  Tap a reward to include or hide it. Add your own private
                  favourites too.
                </p>
                <div className="reward-chips">
                  {[...starterRewards, ...customRewards].map((r) => (
                    <button
                      type="button"
                      className={
                        hiddenRewards.includes(r)
                          ? "reward-chip off"
                          : "reward-chip"
                      }
                      onClick={() =>
                        setHiddenRewards((items) =>
                          items.includes(r)
                            ? items.filter((x) => x !== r)
                            : [...items, r],
                        )
                      }
                      key={r}
                    >
                      {hiddenRewards.includes(r) ? "＋" : "✓"} {r}
                    </button>
                  ))}
                </div>
                <div className="custom-reward">
                  <input
                    value={newReward}
                    onChange={(e) => setNewReward(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") addReward();
                    }}
                    placeholder="Add your own reward…"
                    aria-label="Custom reward"
                  />
                  <Button onClick={addReward}>Add</Button>
                </div>
              </div>
              <div className="hall">
                <h3>Hall of Rest</h3>
                {hall.length === 0 ? (
                  <p className="hall-empty">
                    Completed rewards will live here in exhausted glory.
                  </p>
                ) : (
                  hall.map((x) => (
                    <div className="hall-item" key={x.id}>
                      <span>🏆</span>
                      <div>
                        <strong>{x.champion}</strong>
                        <small>{x.reward}</small>
                      </div>
                      <time>
                        {new Date(x.completedAt).toLocaleDateString("en-GB", {
                          day: "numeric",
                          month: "short",
                        })}
                      </time>
                    </div>
                  ))
                )}
              </div>
            </section>
          )}
        </TabsContent>
        {accountUser && coupleId && <TabsContent value="talk" forceMount hidden={currentTab !== "talk"}>
          <TiredTalk user={accountUser} coupleId={coupleId} active={currentTab === "talk"} onUnreadChange={setTalkUnread} />
        </TabsContent>}
        <TabsContent value="achievements">
          <section className="page-card">
            <span className="eyebrow">YOUR TROPHY CABINET</span>
            <h2>Achievements</h2>
            <div className="achievement-grid">
              {achievements.map((x) => (
                <div
                  className={
                    x.unlocked ? "achievement unlocked" : "achievement"
                  }
                  key={x.title}
                >
                  <span>{x.icon}</span>
                  <div>
                    <strong>{x.title}</strong>
                    <p>{x.text}</p>
                  </div>
                  <small>{x.unlocked ? "Unlocked" : "Locked"}</small>
                </div>
              ))}
            </div>
          </section>
        </TabsContent>
      </Tabs>
      <footer>
        Made for tired couples everywhere · Just for fun, not a medical fatigue
        measure.
      </footer>
    </main>
  );
}
