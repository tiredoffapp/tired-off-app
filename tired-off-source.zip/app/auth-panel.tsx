"use client";

import { useEffect, useState } from "react";
import {
  ArrowRight,
  AtSign,
  Check,
  Copy,
  Heart,
  LockKeyhole,
  UserRound,
  Users,
} from "lucide-react";
import type { User } from "@supabase/supabase-js";
import { Button } from "@/components/ui/button";
import { supabase, supabaseConfigured } from "@/lib/supabase";
import { authRedirectUrl, startGoogleOAuth } from "@/lib/native-auth";

type Pairing = {
  id: string;
  name: string;
  invite_code: string;
  members: number;
  role: string;
};
function PairingSection({ user }: { user: User }) {
  const [pairing, setPairing] = useState<Pairing | null>(null);
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState<"home" | "create" | "join">("home");
  const [name, setName] = useState("Our Tired-Off");
  const [code, setCode] = useState(
    () => new URLSearchParams(window.location.search).get("invite") || "",
  );
  const [message, setMessage] = useState("");
  const [copied, setCopied] = useState(false);
  async function load() {
    setLoading(true);
    const { data: member, error } = await supabase
      .from("couple_members")
      .select("couple_id,role")
      .eq("user_id", user.id)
      .maybeSingle();
    if (error) {
      setMessage(
        "Pairing setup could not be loaded. Please check the Supabase database setup.",
      );
      setLoading(false);
      return;
    }
    if (!member) {
      setPairing(null);
      setLoading(false);
      return;
    }
    const [{ data: couple }, { count }] = await Promise.all([
      supabase
        .from("couples")
        .select("id,name,invite_code")
        .eq("id", member.couple_id)
        .single(),
      supabase
        .from("couple_members")
        .select("*", { count: "exact", head: true })
        .eq("couple_id", member.couple_id),
    ]);
    if (couple)
      setPairing({ ...couple, members: count || 1, role: member.role });
    setLoading(false);
  }
  useEffect(() => {
    load();
  }, [user.id]);
  async function create() {
    setMessage("");
    const { error } = await supabase.rpc("create_tired_off_couple", {
      couple_name: name,
    });
    if (error) {
      setMessage(error.message);
      return;
    }
    await load();
  }
  async function join() {
    setMessage("");
    const clean = code.trim().toUpperCase();
    if (clean.length < 6) {
      setMessage("Enter the invitation code from your partner.");
      return;
    }
    const { error } = await supabase.rpc("join_tired_off_couple", {
      code: clean,
    });
    if (error) {
      setMessage(error.message);
      return;
    }
    await load();
  }
  async function copyInvite() {
    if (!pairing) return;
    const link = `${window.location.origin}?invite=${pairing.invite_code}`;
    await navigator.clipboard.writeText(
      `Join my Tired-Off with code ${pairing.invite_code}: ${link}`,
    );
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  }
  if (loading) return <div className="pair-loading">Checking your couple…</div>;
  if (pairing)
    return (
      <div className="paired-card">
        <span className="pair-heart">
          <Heart />
        </span>
        <div>
          <span className="eyebrow">YOUR COUPLE</span>
          <h2>{pairing.name}</h2>
          <p>
            {pairing.members >= 2
              ? "You’re paired and ready for a proper Tired-Off."
              : "Waiting for your partner to join."}
          </p>
        </div>
        {pairing.members < 2 ? (
          <>
            <div className="invite-code">
              <small>PRIVATE INVITE CODE</small>
              <strong>{pairing.invite_code}</strong>
            </div>
            <Button variant="outline" onClick={copyInvite}>
              {copied ? <Check /> : <Copy />}
              {copied ? "Copied" : "Copy invitation"}
            </Button>
          </>
        ) : (
          <div className="pair-complete">
            <Users />
            <span>
              <strong>2 of 2 joined</strong>
              <small>Couple connected</small>
            </span>
          </div>
        )}
      </div>
    );
  return (
    <div className="pair-setup">
      <span className="eyebrow">PAIR WITH YOUR PARTNER</span>
      <h2>Build your shared Tired-Off</h2>
      <p>
        Create a new couple and send the code, or enter the code your partner
        sent you.
      </p>
      {mode === "home" && (
        <div className="pair-buttons">
          <Button onClick={() => setMode("create")}>
            <Heart />
            Create our couple
          </Button>
          <Button variant="outline" onClick={() => setMode("join")}>
            <Users />
            Enter invite code
          </Button>
        </div>
      )}
      {mode === "create" && (
        <div className="pair-form">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Our Tired-Off"
          />
          <Button onClick={create}>Create and get code</Button>
          <button onClick={() => setMode("home")}>Back</button>
        </div>
      )}
      {mode === "join" && (
        <div className="pair-form">
          <input
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            placeholder="8-character code"
            maxLength={8}
          />
          <Button onClick={join}>Join my partner</Button>
          <button onClick={() => setMode("home")}>Back</button>
        </div>
      )}
      {message && <p className="pair-message">{message}</p>}
    </div>
  );
}

export function AuthPanel({
  user,
  onContinue,
  onGuest,
  onSignOut,
}: {
  user: User | null;
  onContinue: (user: User) => void;
  onGuest: () => void;
  onSignOut: () => void;
}) {
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [recovering, setRecovering] = useState(
    () => localStorage.getItem("tired-off-password-recovery") === "yes",
  );
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  async function submit() {
    if (!supabaseConfigured) {
      setMessage("Account connection is still being configured.");
      return;
    }
    if (!email.trim() || password.length < 6) {
      setMessage("Enter your email and a password of at least six characters.");
      return;
    }
    setBusy(true);
    setMessage("");
    if (creating) {
      const { data, error } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        options: {
          emailRedirectTo: authRedirectUrl(),
          data: { display_name: name.trim() || email.split("@")[0] },
        },
      });
      if (error) setMessage(error.message);
      else if (data.user && !data.session)
        setMessage(
          "Check your email, tap the confirmation link, then return here and sign in.",
        );
      else if (data.user) onContinue(data.user);
    } else {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });
      if (error) setMessage(error.message);
      else if (data.user) onContinue(data.user);
    }
    setBusy(false);
  }
  async function sendReset() {
    if (!email.trim()) {
      setMessage("Enter your email address first.");
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: authRedirectUrl(),
    });
    setMessage(
      error
        ? error.message
        : "Password reset email sent. Open the link in that email to choose a new password.",
    );
    setBusy(false);
  }
  async function updatePassword() {
    if (password.length < 6) {
      setMessage("Your new password must contain at least six characters.");
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    if (error) setMessage(error.message);
    else {
      localStorage.removeItem("tired-off-password-recovery");
      setRecovering(false);
      setMessage("Password updated successfully.");
    }
    setBusy(false);
  }
  async function googleSignIn() {
    setMessage("");
    setBusy(true);
    try {
      await startGoogleOAuth();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Google sign-in could not be started.");
    }
    setBusy(false);
  }
  if (recovering)
    return (
      <main className="auth-screen">
        <section className="auth-card">
          <img src="/tired-off-logo.png" alt="Tired-Off" />
          <span className="eyebrow">SECURE YOUR ACCOUNT</span>
          <h1>Choose a new password</h1>
          <p>Enter a new password of at least six characters.</p>
          <div className="auth-fields">
            <label>
              <span>
                <LockKeyhole /> New password
              </span>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="new-password"
              />
            </label>
          </div>
          {message && <p className="auth-message">{message}</p>}
          <Button
            className="auth-submit"
            disabled={busy}
            onClick={updatePassword}
          >
            {busy ? "Updating…" : "Save new password"}
          </Button>
        </section>
      </main>
    );
  if (user)
    return (
      <main className="auth-screen">
        <section className="auth-card account-card">
          <img src="/tired-off-logo.png" alt="Tired-Off" />
          <span className="eyebrow">YOUR TIRED-OFF ACCOUNT</span>
          <h1>You&apos;re signed in</h1>
          <p>{user.email}</p>
          <PairingSection user={user} />
          <Button
            size="lg"
            className="auth-submit"
            onClick={() => onContinue(user)}
          >
            Continue to Tired-Off
            <ArrowRight />
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="guest-button"
            onClick={onSignOut}
          >
            Sign out
          </Button>
        </section>
      </main>
    );
  return (
    <main className="auth-screen">
      <section className="auth-card">
        <img src="/tired-off-logo.png" alt="Tired-Off" />
        <span className="eyebrow">YOUR TIRED-OFF ACCOUNT</span>
        <h1>{creating ? "Create your account" : "Welcome back"}</h1>
        <p>
          {creating
            ? "Your scores, rewards and weekly championship will follow you across devices."
            : "Sign in to return to your shared Tired-Off."}
        </p>
        <div className="auth-fields">
          {creating && (
            <label>
              <span>
                <UserRound />
                Your name
              </span>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Joe"
                autoComplete="name"
              />
            </label>
          )}
          <label>
            <span>
              <AtSign />
              Email address
            </span>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              autoComplete="email"
            />
          </label>
          <label>
            <span>
              <LockKeyhole />
              Password
            </span>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="At least 6 characters"
              autoComplete={creating ? "new-password" : "current-password"}
              onKeyDown={(e) => {
                if (e.key === "Enter") submit();
              }}
            />
          </label>
        </div>
        {message && <p className="auth-message">{message}</p>}
        <Button
          size="lg"
          className="auth-submit"
          disabled={busy}
          onClick={submit}
        >
          {busy ? "Please wait…" : creating ? "Create account" : "Sign in"}
          <ArrowRight />
        </Button>
        <button
          className="auth-switch"
          type="button"
          onClick={() => {
            setCreating((x) => !x);
            setMessage("");
          }}
        >
          {creating
            ? "Already registered? Sign in"
            : "New to Tired-Off? Create an account"}
        </button>
        {!creating && (
          <button className="auth-switch" type="button" onClick={sendReset}>
            Forgot your password?
          </button>
        )}
        <div className="auth-divider">
          <span>or</span>
        </div>
        <Button
          size="lg"
          variant="outline"
          className="google-button"
          onClick={googleSignIn}
        >
          <b>G</b> Continue with Google
        </Button>
        <Button
          size="lg"
          variant="outline"
          className="guest-button"
          onClick={onGuest}
        >
          Continue as guest on this device
        </Button>
        <small>
          Your Tired-Off account is independent and securely managed.
        </small>
      </section>
    </main>
  );
}
