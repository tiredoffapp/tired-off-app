"use client";
import { useEffect, useMemo, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { Crown, Eye, Gift, LockKeyhole, Moon, RefreshCw, Shuffle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { supabase } from "@/lib/supabase";
import type { SharedConfig } from "@/app/shared-scorecard";
type Member = { user_id: string; name: string };
type Answers = { values?: Record<string, number>; cards?: string[]; conceded?: boolean; reason?: string };
type Score = { user_id: string; score: number; answers?: Answers };
type Battle = { date: string; scores: Score[]; winner_id?: string; conceded_by?: string };
type Reward = {
  week_start: string;
  champion_id: string;
  reward: string;
  completed_at: string | null;
};
type Game = { members: Member[]; battles: Battle[]; rewards: Reward[]; reward_shuffles?: string[]; config?: SharedConfig };
type Standing = Member & { crowns: number; total: number; average: number };
const rewardPool = [
  "Two-hour uninterrupted nap",
  "20-minute foot rub",
  "Shoulder or back massage",
  "Breakfast in bed",
  "A proper lie-in",
  "Evening off household duties",
  "Bedtime duty covered",
  "Favourite meal cooked or ordered",
  "Control of the TV for an evening",
  "A hot bath with no interruptions",
  "Tea or coffee in bed",
  "One chore wiped from the list",
  "An uninterrupted hour to yourself",
  "Choice of the next date night",
  "A favourite snack or small treat",
  "No-questions-asked early night",
];
function weekKey(value = new Date()) {
  const d = new Date(value);
  d.setHours(0, 0, 0, 0);
  d.setDate(d.getDate() - ((d.getDay() + 6) % 7));
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function isUnlocked(key: string) {
  const d = new Date(`${key}T19:00:00`);
  d.setDate(d.getDate() + 6);
  return new Date() >= d;
}
function rewardCards(key: string) {
  let seed = [...key].reduce((n, c) => n + c.charCodeAt(0), 0);
  const result: string[] = [];
  while (result.length < 3) {
    seed = (seed * 9301 + 49297) % 233280;
    const reward = rewardPool[seed % rewardPool.length];
    if (!result.includes(reward)) result.push(reward);
  }
  return result;
}
function useGame() {
  const [data, setData] = useState<Game | null>(null);
  const [message, setMessage] = useState("");
  const [refreshing, setRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  async function refresh() {
    setRefreshing(true);
    setMessage("");
    const [{ data: game, error }, { data: config }] = await Promise.all([
      supabase.rpc("get_shared_game"),
      supabase.rpc("get_shared_scorecard"),
    ]);
    if (error) {
      setMessage("Couldn’t refresh just now. Check your connection and try again.");
    } else {
      setData({ ...(game as Game), config: (config as SharedConfig) || undefined });
      setLastUpdated(new Date());
    }
    setRefreshing(false);
  }
  useEffect(() => {
    refresh();
  }, []);
  return { data, message, refresh, refreshing, lastUpdated };
}
function standings(game: Game, battles: Battle[]): Standing[] {
  return game.members
    .map((m) => {
      let crowns = 0,
        total = 0,
        count = 0;
      battles.forEach((b) => {
        const mine = b.scores.find((s) => s.user_id === m.user_id);
        if (b.conceded_by) {
          if (b.winner_id === m.user_id) crowns++;
          return;
        }
        if (!mine) return;
        total += mine.score;
        count++;
        const top = Math.max(...b.scores.map((s) => s.score));
        if (
          mine.score === top &&
          b.scores.filter((s) => s.score === top).length === 1
        )
          crowns++;
      });
      return {
        ...m,
        crowns,
        total,
        average: count ? Math.round(total / count) : 0,
      };
    })
    .sort((a, b) => b.crowns - a.crowns || b.total - a.total);
}
function champion(s: Standing[]) {
  if (!s.length) return null;
  if (s.length > 1 && s[0].crowns === s[1].crowns && s[0].total === s[1].total)
    return null;
  return s[0];
}
export function OnlineChampionship() {
  const { data, message, refresh, refreshing, lastUpdated } = useGame();
  const [historyLimit, setHistoryLimit] = useState(7);
  const [reviewBattle, setReviewBattle] = useState<Battle | null>(null);
  if (!data)
    return (
      <section className="page-card online-shared-loading">
        <Moon />
        <p>{message || "Loading your shared championship…"}</p>
      </section>
    );
  const month = new Date().toISOString().slice(0, 7);
  const battles = data.battles.filter((b) => b.date.startsWith(month));
  const table = standings(data, battles);
  const latestWeek = weekKey(new Date(`${data.battles[0]?.date || weekKey()}T12:00:00`));
  const latestWeekBattles = data.battles.filter((b) => weekKey(new Date(`${b.date}T12:00:00`)) === latestWeek);
  const weeklyTable = standings(data, latestWeekBattles);
  const weeklyWinner = champion(weeklyTable);
  const scoredBattles = latestWeekBattles.filter((b) => b.scores.length > 1 && !b.conceded_by);
  const closest = [...scoredBattles].sort((a, b) => Math.abs(a.scores[0].score - a.scores[1].score) - Math.abs(b.scores[0].score - b.scores[1].score))[0];
  const biggestScore = scoredBattles.flatMap((b) => b.scores.map((s) => ({ ...s, date: b.date }))).sort((a, b) => b.score - a.score)[0];
  return (
    <section className="page-card">
      <span className="eyebrow">SHARED CHAMPIONSHIP</span>
      <h2>The tiredness championship</h2>
      <p className="section-copy">
        Updated for both phones whenever a daily result is revealed.
      </p>
      <div className="leaderboard">
        {table.map((s, i) => (
          <div className="leader" key={s.user_id}>
            <span className="place">
              {i === 0 && battles.length ? "👑" : "#2"}
            </span>
            <div>
              <strong>{s.name}</strong>
              <small>
                {s.crowns} wins · Average {s.average}/100
              </small>
            </div>
            <b>{s.crowns}</b>
          </div>
        ))}
      </div>
      {latestWeekBattles.length > 0 && (
        <section className="weekly-story">
          <div className="weekly-story-heading">
            <div><span className="eyebrow">WEEKLY STORY</span><h3>{new Date(`${latestWeek}T12:00:00`).toLocaleDateString("en-GB", { day: "numeric", month: "long" })} week</h3></div>
            <span>📖</span>
          </div>
          <div className="weekly-story-grid">
            <div><span>👑</span><strong>{weeklyWinner ? `${weeklyWinner.name} leads` : "Dead level"}</strong><small>{latestWeekBattles.length} completed {latestWeekBattles.length === 1 ? "day" : "days"}</small></div>
            <div><span>🤏</span><strong>{closest ? `${Math.abs(closest.scores[0].score - closest.scores[1].score)}-point nail-biter` : "No close call yet"}</strong><small>{closest ? new Date(`${closest.date}T12:00:00`).toLocaleDateString("en-GB", { weekday: "long" }) : "More evidence required"}</small></div>
            <div><span>🔥</span><strong>{biggestScore ? `${biggestScore.score}/100` : "—"}</strong><small>{biggestScore ? `${data.members.find((m) => m.user_id === biggestScore.user_id)?.name}'s biggest score` : "Highest score this week"}</small></div>
          </div>
          <p>{weeklyWinner ? `${weeklyWinner.name} currently holds the crown. Sunday’s final result will settle the argument.` : "Nothing separates you yet. This week may require snacks and a steward’s enquiry."}</p>
        </section>
      )}
      {data.rewards.length > 0 && (
        <section className="weekly-records" aria-label="Previous weekly champions">
          <div className="weekly-records-heading">
            <div>
              <span className="eyebrow">THE STORY SO FAR</span>
              <h3>Previous weekly champions</h3>
            </div>
            <span aria-hidden="true">🏆</span>
          </div>
          <div className="weekly-record-list">
            {data.rewards.map((reward) => {
              const weekBattles = data.battles.filter((battle) => weekKey(new Date(`${battle.date}T12:00:00`)) === reward.week_start);
              const finalTable = standings(data, weekBattles);
              const winnerName = data.members.find((member) => member.user_id === reward.champion_id)?.name || "Weekly champion";
              return (
                <article className="weekly-record" key={reward.week_start}>
                  <div className="weekly-record-crown">👑</div>
                  <div className="weekly-record-copy">
                    <small>Week beginning {new Date(`${reward.week_start}T12:00:00`).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}</small>
                    <strong>{winnerName} won the week</strong>
                    <span className="weekly-record-reward">🎁 {reward.reward}</span>
                    <span className="weekly-record-scores">
                      {finalTable.map((player) => `${player.name}: ${player.crowns} ${player.crowns === 1 ? "crown" : "crowns"}, ${player.total} points`).join(" · ")}
                    </span>
                  </div>
                  <span className={reward.completed_at ? "reward-status enjoyed" : "reward-status owed"}>
                    {reward.completed_at ? "Enjoyed ✓" : "Still owed"}
                  </span>
                </article>
              );
            })}
          </div>
        </section>
      )}
      <h3>Battle history</h3>
      {data.battles.length === 0 ? (
        <div className="empty">
          <Moon />
          <p>Your first completed battle will appear here.</p>
        </div>
      ) : (
        <div className="history-list">
          {data.battles.slice(0, historyLimit).map((b) => {
            const ordered = [...b.scores].sort((a, z) => z.score - a.score);
            const draw = ordered[0]?.score === ordered[1]?.score;
            const winner = data.members.find(
              (m) => m.user_id === (b.winner_id || ordered[0]?.user_id),
            )?.name;
            return (
              <div key={b.date} className="history-battle">
                <span>
                  {new Date(`${b.date}T12:00:00`).toLocaleDateString("en-GB", {
                    day: "numeric",
                    month: "short",
                  })}
                </span>
                <strong>{b.conceded_by ? `${winner} won by concession` : draw ? "Draw" : `${winner} won`}</strong>
                <small>
                  {b.conceded_by ? "Today's score was conceded" : b.scores
                    .map(
                      (s) =>
                        `${data.members.find((m) => m.user_id === s.user_id)?.name} ${s.score}`,
                    )
                    .join(" · ")}
                </small>
                {!b.conceded_by && (
                  <Button variant="ghost" className="history-review" onClick={() => setReviewBattle(b)}>
                    <Eye /> Review
                  </Button>
                )}
              </div>
            );
          })}
        </div>
      )}
      {data.battles.length > historyLimit && (
        <Button variant="outline" className="history-more" onClick={() => setHistoryLimit((n) => n + 14)}>Show older battles</Button>
      )}
      <Button variant="outline" className="shared-refresh" onClick={refresh} disabled={refreshing}>
        <RefreshCw className={refreshing ? "refresh-spinning" : ""} />
        {refreshing ? "Refreshing…" : "Refresh results"}
      </Button>
      <p className={message ? "refresh-status error" : "refresh-status"} aria-live="polite">
        {message || (lastUpdated ? `Results updated at ${lastUpdated.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}` : "")}
      </p>
      <Dialog open={!!reviewBattle} onOpenChange={(open) => !open && setReviewBattle(null)}>
        <DialogContent className="battle-review-dialog">
          <DialogHeader>
            <DialogTitle>Review the evidence</DialogTitle>
            <DialogDescription>
              {reviewBattle && new Date(`${reviewBattle.date}T12:00:00`).toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" })} · These locked answers cannot be changed.
            </DialogDescription>
          </DialogHeader>
          {reviewBattle && (
            <div className="past-breakdown">
              <div className="past-score-summary">
                {reviewBattle.scores.map((score) => (
                  <div key={score.user_id}><span>{data.members.find((m) => m.user_id === score.user_id)?.name || "Partner"}</span><strong>{score.score}<small>/100</small></strong></div>
                ))}
              </div>
              {reviewBattle.scores.some((score) => score.answers?.values) ? (
                <>
                  <div className="past-breakdown-head"><span>Measurement</span>{reviewBattle.scores.map((score) => <b key={score.user_id}>{data.members.find((m) => m.user_id === score.user_id)?.name || "Partner"}</b>)}</div>
                  {Array.from(new Set(reviewBattle.scores.flatMap((score) => Object.keys(score.answers?.values || {})))).map((id) => {
                    const metric = data.config?.active_metrics.find((item) => item.id === id);
                    const label = metric?.label || id.replace(/^custom-\d+-?/, "").replace(/[-_]/g, " ").replace(/^./, (c) => c.toUpperCase());
                    const suffix = metric?.suffix || "";
                    return <div className="past-breakdown-row" key={id}><span>{label}</span>{reviewBattle.scores.map((score) => <b key={score.user_id}>{score.answers?.values?.[id] ?? "—"}{suffix}</b>)}</div>;
                  })}
                  <div className="past-cards"><h4>Exhaustion cards</h4>{reviewBattle.scores.map((score) => {
                    const cards = score.answers?.cards || [];
                    return <div key={score.user_id}><b>{data.members.find((m) => m.user_id === score.user_id)?.name || "Partner"}</b><span>{cards.length ? cards.map((id) => { const card = data.config?.active_cards.find((item) => item.id === id); return card ? `${card.emoji} ${card.label}` : id.replace(/[-_]/g, " "); }).join(" · ") : "No cards used"}</span></div>;
                  })}</div>
                </>
              ) : <p className="past-unavailable">The totals are saved, but the detailed answers need the one-time database update below.</p>}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
export function OnlineRewards({ user }: { user: User }) {
  const { data, message, refresh, refreshing, lastUpdated } = useGame();
  const [busy, setBusy] = useState(false);
  const thisWeek = weekKey();
  const weekBattles = useMemo(
    () =>
      data?.battles.filter(
        (b) => weekKey(new Date(`${b.date}T12:00:00`)) === thisWeek,
      ) || [],
    [data, thisWeek],
  );
  if (!data)
    return (
      <section className="page-card online-shared-loading">
        <Gift />
        <p>{message || "Loading your shared rewards…"}</p>
      </section>
    );
  const table = standings(data, weekBattles);
  const winner = champion(table);
  const saved = data.rewards.find((r) => r.week_start === thisWeek);
  const shuffleUsed = data.reward_shuffles?.includes(thisWeek) || false;
  const cards = rewardCards(shuffleUsed ? `${thisWeek}-shuffled` : thisWeek);
  async function choose(reward: string) {
    if (!winner || winner.user_id !== user.id) return;
    setBusy(true);
    await supabase.rpc("save_weekly_reward", {
      p_week_start: thisWeek,
      p_reward: reward,
    });
    await refresh();
    setBusy(false);
  }
  async function complete() {
    setBusy(true);
    await supabase.rpc("complete_weekly_reward", { p_week_start: thisWeek });
    await refresh();
    setBusy(false);
  }
  async function shuffleRewards() {
    if (!winner || winner.user_id !== user.id || shuffleUsed) return;
    setBusy(true);
    const { error } = await supabase.rpc("use_weekly_reward_shuffle", { p_week_start: thisWeek });
    if (error) {
      window.alert("The shuffle needs the one-time Supabase update before it can be used.");
    } else {
      await refresh();
    }
    setBusy(false);
  }
  return (
    <section className="page-card rewards-page">
      <span className="eyebrow">SHARED REST REWARDS</span>
      <h2>Victory is tiring. You&apos;ve earned this.</h2>
      <p className="section-copy">
        Daily wins earn crowns on both phones. Sunday&apos;s champion chooses
        the reward.
      </p>
      <div className="weekly-score">
        {table.map((s, i) => (
          <div
            className={
              winner?.user_id === s.user_id && weekBattles.length
                ? "weekly-player leading"
                : "weekly-player"
            }
            key={s.user_id}
          >
            <span>{i === 0 ? "😴" : "🥱"}</span>
            <div>
              <strong>{s.name}</strong>
              <small>{s.total} tired-points this week</small>
            </div>
            <b>
              {s.crowns}
              <small> crowns</small>
            </b>
          </div>
        ))}
      </div>
      {saved ? (
        <>
          <div className="reward-reveal">
            <div className="reward-crown">{saved.completed_at ? "✅" : "👑"}</div>
            <h3>
              {data.members.find((m) => m.user_id === saved.champion_id)?.name}
              &apos;s reward
            </h3>
            <p className="chosen-online-reward">{saved.reward}</p>
            {saved.champion_id === user.id && !saved.completed_at && (
              <Button disabled={busy} onClick={complete}>
                Mark as enjoyed
              </Button>
            )}
          </div>
          <div className="sunday-summary">
            <span className="eyebrow">SUNDAY SUMMARY</span>
            <h3>The week in tiredness</h3>
            <p>{weekBattles.length} daily battles completed. {winner?.name || "Your household"} finished with {winner?.crowns || 0} crowns and {winner?.total || 0} tired-points.</p>
            <div>{table.map((s) => <span key={s.user_id}><strong>{s.name}</strong><b>{s.crowns} crowns</b><small>{s.total} points · {s.average}/100 average</small></span>)}</div>
          </div>
        </>
      ) : !isUnlocked(thisWeek) ? (
        <div className="reward-locked">
          <LockKeyhole />
          <div>
            <span className="eyebrow">REVEAL LOCKED</span>
            <h3>Sunday at 7:00 pm</h3>
            <p>
              {weekBattles.length && winner
                ? `${winner.name} is currently leading.`
                : "Complete daily battles to begin the race."}
            </p>
          </div>
        </div>
      ) : !winner ? (
        <div className="reward-reveal">
          <div className="reward-crown">🤝</div>
          <h3>Joint champions</h3>
          <p>
            You finished completely level this week. Agree on a reward
            together—you&apos;ve both earned it.
          </p>
        </div>
      ) : winner.user_id !== user.id ? (
        <div className="reward-reveal">
          <Crown />
          <h3>{winner.name} won the week</h3>
          <p>
            The champion&apos;s three mystery rewards are ready on their phone.
          </p>
        </div>
      ) : (
        <div className="reward-game">
          <p className="reward-winner">
            <Crown />
            You won the week—choose your reward
          </p>
          <div className="reward-cards">
            {cards.map((reward, i) => (
              <button
                disabled={busy}
                type="button"
                onClick={() => choose(reward)}
                className="reward-card"
                key={reward}
              >
                <span>{i === 0 ? "🌙" : i === 1 ? "💆" : "☕"}</span>
                <strong>{reward}</strong>
                <small>Tap to choose</small>
              </button>
            ))}
          </div>
          <div className="reward-shuffle">
            {!shuffleUsed ? (
              <Button variant="outline" disabled={busy} onClick={shuffleRewards}>
                <Shuffle /> Shuffle rewards once
              </Button>
            ) : (
              <p><Shuffle /> Shuffle used — these three cards are final.</p>
            )}
          </div>
        </div>
      )}
      <Button variant="outline" className="shared-refresh" onClick={refresh} disabled={refreshing}>
        <RefreshCw className={refreshing ? "refresh-spinning" : ""} />
        {refreshing ? "Refreshing…" : "Refresh weekly score"}
      </Button>
      <p className={message ? "refresh-status error" : "refresh-status"} aria-live="polite">
        {message || (lastUpdated ? `Weekly score updated at ${lastUpdated.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })}` : "")}
      </p>
    </section>
  );
}
