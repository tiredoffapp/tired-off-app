"use client";
import { useEffect, useMemo, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { CheckCircle2, Crown, LockKeyhole, Save, Sparkles, Flag } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Slider } from "@/components/ui/slider";
import {
  SharedScorecardEditor,
  type SharedConfig,
} from "@/app/shared-scorecard";
import { supabase } from "@/lib/supabase";
type Answers = { values: Record<string, number>; cards: string[] };
type Battle = {
  status: "open" | "waiting" | "revealed" | "unpaired";
  submitted?: boolean;
  scores?: { user_id: string; score: number; answers?: Answers }[];
  concession?: { user_id: string; reason: string };
};
const CHILDCARE_WEIGHT_INCREASE_DATE = "2026-09-28";
function today() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function defaultValue(id: string) {
  return (
    (
      {
        sleep: 7,
        work: 8,
        wakeups: 1,
        awake: 20,
        chores: 2,
        childcare: 2,
        stress: 3,
        physical: 1,
      } as Record<string, number>
    )[id] || 0
  );
}

function tiredComment(score: number, style: "fair" | "funny" | "survival") {
  if (style === "survival") {
    if (score >= 70) return "You have presented a powerful case. Proceed gently.";
    if (score >= 40) return "Respectably tired. Negotiations remain possible.";
    return "Looking surprisingly functional. Choose your argument carefully.";
  }
  if (style === "fair") {
    if (score >= 70) return "A seriously demanding day—your score reflects it.";
    if (score >= 40) return "A solid tiredness score. Lock it in when it feels accurate.";
    return "A lighter day so far. You can keep updating this before lock-in.";
  }
  if (score >= 85) return "Running entirely on caffeine and determination.";
  if (score >= 70) return "Your pillow is starting to look like a life goal.";
  if (score >= 55) return "Officially too tired to decide what’s for tea.";
  if (score >= 40) return "Definitely tired — but still pretending you’re fine.";
  if (score >= 25) return "A little weary. The sofa is calling your name.";
  return "Suspiciously well rested. Are you sure you live here?";
}

export function OnlineBattle({ user, playStyle = "fair" }: { user: User; playStyle?: "fair" | "funny" | "survival" }) {
  const [answers, setAnswers] = useState<Answers>({ values: {}, cards: [] });
  const [draftLoaded, setDraftLoaded] = useState(false);
  const [battle, setBattle] = useState<Battle>({ status: "open" });
  const [config, setConfig] = useState<SharedConfig | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [reviewOpen, setReviewOpen] = useState(false);
  async function loadConfig() {
    const { data, error } = await supabase.rpc("get_shared_scorecard");
    if (!error && data) {
      const shared = data as SharedConfig;
      setConfig({
        ...shared,
        // Childcare can cover a full day even when an existing shared scorecard still stores the old limit.
        active_metrics: shared.active_metrics.map((metric) =>
          metric.id === "childcare"
            ? { ...metric, max: 24, step: 0.5 }
            : metric,
        ),
      });
    }
    return error;
  }
  async function refresh() {
    const [{ data, error }] = await Promise.all([
      supabase.rpc("get_daily_battle", { p_date: today() }),
      loadConfig(),
    ]);
    if (error) {
      setMessage(navigator.onLine ? "We couldn’t load today’s battle. Please try again." : "You’re offline. Reconnect and try again—your unfinished sliders are safe on this phone.");
      return;
    }
    setBattle(data as Battle);
  }
  useEffect(() => {
    refresh();
  }, []);
  useEffect(() => {
    const key = `tired-off-draft:${user.id}:${today()}`;
    try {
      const saved = localStorage.getItem(key);
      if (saved) {
        const draft = JSON.parse(saved) as Answers;
        if (draft?.values && Array.isArray(draft?.cards)) setAnswers(draft);
      }
    } catch {
      // A damaged local draft should never stop today's check-in loading.
    }
    setDraftLoaded(true);
  }, [user.id]);
  useEffect(() => {
    if (!draftLoaded || battle.status !== "open") return;
    localStorage.setItem(
      `tired-off-draft:${user.id}:${today()}`,
      JSON.stringify(answers),
    );
  }, [answers, battle.status, draftLoaded, user.id]);
  const score = useMemo(() => {
    if (!config) return 0;
    const base = config.active_metrics.reduce((n, m) => {
      const value = answers.values[m.id] ?? defaultValue(m.id);
      const weight = m.id === "childcare" && today() >= CHILDCARE_WEIGHT_INCREASE_DATE
        ? 4
        : m.weight;
      return (
        n +
        (m.invert !== undefined
          ? Math.max(0, m.invert - value) * weight
          : value * weight)
      );
    }, 0);
    const extras = answers.cards.reduce(
      (n, id) =>
        n + (config.active_cards.find((c) => c.id === id)?.points || 0),
      0,
    );
    return Math.max(0, Math.min(100, Math.round(base + extras)));
  }, [answers, config]);
  async function submit() {
    setBusy(true);
    setMessage("");
    const { data, error } = await supabase.rpc("submit_daily_checkin", {
      p_date: today(),
      p_score: score,
      p_answers: {
        values: Object.fromEntries((config?.active_metrics || []).map((m) => [m.id, answers.values[m.id] ?? defaultValue(m.id)])),
        cards: answers.cards,
      },
    });
    if (error) setMessage(error.message);
    else {
      localStorage.removeItem(`tired-off-draft:${user.id}:${today()}`);
      setBattle(data as Battle);
      setReviewOpen(false);
    }
    setBusy(false);
  }
  async function concede() {
    if (!window.confirm("Concede today? Your partner wins this round, and you can't undo it.")) return;
    setBusy(true);
    setMessage("");
    const { data, error } = await supabase.rpc("concede_daily_battle", {
      p_date: today(), p_reason: "I chose the fun. You win today! 🎢",
    });
    if (error) setMessage("Conceding isn't ready yet. The database update still needs to be run.");
    else {
      localStorage.removeItem(`tired-off-draft:${user.id}:${today()}`);
      setBattle(data as Battle);
    }
    setBusy(false);
  }
  if (!config)
    return (
      <section className="waiting-card">
        <Sparkles />
        <h2>Loading your shared scorecard…</h2>
        <p>{message || "Checking this week’s locked setup."}</p>
        {message && <Button variant="outline" onClick={refresh}>Try again</Button>}
      </section>
    );
  const editor = <SharedScorecardEditor config={config} onSaved={loadConfig} />;
  if (battle.status === "revealed") {
    const concession = battle.concession;
    const iConceded = concession?.user_id === user.id;
    const myEntry = battle.scores?.find((s) => s.user_id === user.id);
    const partnerEntry = battle.scores?.find((s) => s.user_id !== user.id);
    const mine = myEntry?.score ?? 0;
    const theirs = partnerEntry?.score ?? 0;
    const result = concession
      ? iConceded ? "Your partner wins today" : "You win today!"
      :
      mine === theirs
        ? "It’s a draw"
        : mine > theirs
          ? "You take today’s crown"
          : "Your partner takes the crown";
    return (
      <>
        <section className="online-result">
          <Crown />
          <span className="eyebrow">TODAY&apos;S RESULT</span>
          <h2>{result}</h2>
          {!concession && <div>
            <strong>
              {mine}
              <small>You</small>
            </strong>
            <b>VS</b>
            <strong>
              {theirs}
              <small>Partner</small>
            </strong>
          </div>}
          <p>{concession ? (iConceded ? "I chose the fun. You win today! 🎢" : "Your partner conceded today. Enjoy your crown!") : myEntry?.answers && partnerEntry?.answers
            ? "Both scores are in. Here's what each of you locked in today."
            : "Both scores are in. The detailed reveal needs the Supabase update."}</p>
        </section>
        {!concession && myEntry?.answers && partnerEntry?.answers && (
          <section className="daily-breakdown" aria-label="Both partners' answers">
            <h3>How your scores add up</h3>
            <div className="breakdown-head"><span>Measurement</span><b>You</b><b>Partner</b></div>
            {config.active_metrics.map((m) => (
              <div className="breakdown-row" key={m.id}>
                <span>{m.label}</span>
                <strong>{myEntry.answers?.values?.[m.id] ?? defaultValue(m.id)}{m.suffix}</strong>
                <strong>{partnerEntry.answers?.values?.[m.id] ?? defaultValue(m.id)}{m.suffix}</strong>
              </div>
            ))}
            <div className="breakdown-head"><span>Exhaustion cards</span><b>You</b><b>Partner</b></div>
            {config.active_cards.filter((card) => myEntry.answers?.cards?.includes(card.id) || partnerEntry.answers?.cards?.includes(card.id)).map((card) => (
              <div className="breakdown-row" key={card.id}>
                <span>{card.emoji} {card.label}</span>
                <strong>{myEntry.answers?.cards?.includes(card.id) ? `${card.points > 0 ? "+" : ""}${card.points}` : "—"}</strong>
                <strong>{partnerEntry.answers?.cards?.includes(card.id) ? `${card.points > 0 ? "+" : ""}${card.points}` : "—"}</strong>
              </div>
            ))}
            {!(myEntry.answers.cards?.length || partnerEntry.answers.cards?.length) && <p className="breakdown-empty">No exhaustion cards used today.</p>}
          </section>
        )}
        {editor}
      </>
    );
  }
  if (battle.status === "waiting")
    return (
      <>
        <section className="waiting-card">
          <LockKeyhole />
          <span className="eyebrow">SCORE LOCKED IN</span>
          <h2>Waiting for your partner</h2>
          <p>
            Your answers are hidden. The result will appear as soon as your
            partner submits.
          </p>
          <Button variant="outline" onClick={refresh}>
            Check for their score
          </Button>
        </section>
        {editor}
      </>
    );
  return (
    <>
      <section className="online-intro">
        <div>
          <span className="eyebrow">PRIVATE DAILY CHECK-IN</span>
          <h2>Your tiredness score</h2>
          <p>This week&apos;s shared scorecard is locked for both partners.</p>
          <p className="tired-label online-tired-comment">{tiredComment(score, playStyle)}</p>
        </div>
        <div className="score-orb">
          <strong>{score}</strong>
          <span>/100</span>
        </div>
      </section>
      <section className="player-card coral online-card">
        <div className="metrics">
          {config.active_metrics.map((m) => {
            const value = answers.values[m.id] ?? defaultValue(m.id);
            return (
              <label className="metric" key={m.id}>
                <span className="metric-label">
                  <span>
                    <Sparkles />
                    {m.label}
                  </span>
                  <b>
                    {value}
                    {m.suffix}
                  </b>
                </span>
                <Slider
                  min={m.min}
                  max={m.max}
                  step={m.step}
                  value={[value]}
                  onValueChange={(v) =>
                    setAnswers({
                      ...answers,
                      values: { ...answers.values, [m.id]: v[0] },
                    })
                  }
                />
              </label>
            );
          })}
        </div>
        <div className="cards-title">Today&apos;s exhaustion cards</div>
        <div className="special-cards">
          {config.active_cards.map((c) => {
            const active = answers.cards.includes(c.id);
            return (
              <button
                type="button"
                className={active ? "special active" : "special"}
                key={c.id}
                onClick={() =>
                  setAnswers({
                    ...answers,
                    cards: active
                      ? answers.cards.filter((x) => x !== c.id)
                      : [...answers.cards, c.id],
                  })
                }
              >
                <span>{c.emoji}</span>
                <span>
                  {c.label}
                  <small>
                    {c.points > 0 ? "+" : ""}
                    {c.points}
                  </small>
                </span>
              </button>
            );
          })}
        </div>
        {message && <p className="online-message">{message}</p>}
        <Button
          size="lg"
          className="online-submit"
          disabled={busy}
          onClick={() => setReviewOpen(true)}
        >
          {busy ? (
            "Submitting…"
          ) : (
            <>
              <Save />
              Lock in today&apos;s score
            </>
          )}
        </Button>
        <Dialog open={reviewOpen} onOpenChange={(open) => !busy && setReviewOpen(open)}>
          <DialogContent className="score-review-dialog">
            <DialogHeader>
              <span className="score-review-icon">🔎</span>
              <DialogTitle>Double-check before locking in</DialogTitle>
              <DialogDescription>
                Once submitted, today&apos;s score cannot be changed. Make sure no slider has wandered off by itself.
              </DialogDescription>
            </DialogHeader>
            <div className="score-review-total">
              <span>Your final score</span>
              <strong>{score}<small>/100</small></strong>
            </div>
            <div className="score-review-list">
              {config.active_metrics.map((metric) => (
                <div key={metric.id}>
                  <span>{metric.label}</span>
                  <strong>{answers.values[metric.id] ?? defaultValue(metric.id)}{metric.suffix}</strong>
                </div>
              ))}
            </div>
            <div className="score-review-cards">
              <strong>Exhaustion cards</strong>
              {answers.cards.length ? (
                <div>{answers.cards.map((id) => {
                  const card = config.active_cards.find((item) => item.id === id);
                  return card ? <span key={id}>{card.emoji} {card.label} ({card.points > 0 ? "+" : ""}{card.points})</span> : null;
                })}</div>
              ) : <p>No exhaustion cards selected.</p>}
            </div>
            {message && <p className="online-message" aria-live="polite">{message}</p>}
            <DialogFooter>
              <DialogClose asChild><Button variant="outline" disabled={busy}>Go back and edit</Button></DialogClose>
              <Button disabled={busy} onClick={submit}>{busy ? "Locking in…" : "Yes, lock it in"}</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
        <div className="concede-action">
          <p>Tired from a day you chose? You can give your partner today's win.</p>
          <Button variant="outline" disabled={busy} onClick={concede}>
            <Flag /> You win today
          </Button>
        </div>
        <p className="private-note">
          <CheckCircle2 />
          Your detailed answers stay private.
        </p>
      </section>
      {editor}
    </>
  );
}
