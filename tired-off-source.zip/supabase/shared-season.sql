-- Shared championship history and Sunday rewards. Run once after daily-battles.sql.

create table if not exists public.weekly_rewards (
  couple_id uuid not null references public.couples(id) on delete cascade,
  week_start date not null,
  champion_id uuid not null references auth.users(id) on delete cascade,
  reward text not null,
  selected_at timestamptz not null default now(),
  completed_at timestamptz,
  primary key (couple_id, week_start)
);

alter table public.weekly_rewards enable row level security;

create or replace function public.get_shared_game()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  cid uuid;
  result jsonb;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  cid := public.my_couple_id();
  if cid is null then return jsonb_build_object('members','[]'::jsonb,'battles','[]'::jsonb,'rewards','[]'::jsonb); end if;

  select jsonb_build_object(
    'members', coalesce((
      select jsonb_agg(jsonb_build_object(
        'user_id', cm.user_id,
        'name', coalesce(nullif(u.raw_user_meta_data->>'display_name',''), split_part(u.email,'@',1), 'Player')
      ) order by cm.joined_at)
      from public.couple_members cm
      join auth.users u on u.id = cm.user_id
      where cm.couple_id = cid
    ), '[]'::jsonb),
    'battles', coalesce((
      select jsonb_agg(jsonb_build_object('date', d.checkin_date, 'scores', d.scores) order by d.checkin_date desc)
      from (
        select checkin_date, jsonb_agg(jsonb_build_object('user_id',user_id,'score',score) order by submitted_at) as scores
        from public.daily_checkins
        where couple_id = cid
        group by checkin_date
        having count(*) = 2
      ) d
    ), '[]'::jsonb),
    'rewards', coalesce((
      select jsonb_agg(jsonb_build_object(
        'week_start', wr.week_start,
        'champion_id', wr.champion_id,
        'reward', wr.reward,
        'completed_at', wr.completed_at
      ) order by wr.week_start desc)
      from public.weekly_rewards wr
      where wr.couple_id = cid
    ), '[]'::jsonb)
  ) into result;
  return result;
end;
$$;

create or replace function public.save_weekly_reward(p_week_start date, p_reward text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare cid uuid;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  cid := public.my_couple_id();
  if cid is null then raise exception 'Pair with your partner first'; end if;
  if trim(coalesce(p_reward,'')) = '' then raise exception 'Choose a reward'; end if;
  insert into public.weekly_rewards(couple_id,week_start,champion_id,reward)
  values(cid,p_week_start,auth.uid(),trim(p_reward))
  on conflict(couple_id,week_start) do nothing;
end;
$$;

create or replace function public.complete_weekly_reward(p_week_start date)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare cid uuid;
begin
  cid := public.my_couple_id();
  update public.weekly_rewards set completed_at = now()
  where couple_id = cid and week_start = p_week_start and champion_id = auth.uid();
end;
$$;

grant execute on function public.get_shared_game() to authenticated;
grant execute on function public.save_weekly_reward(date,text) to authenticated;
grant execute on function public.complete_weekly_reward(date) to authenticated;
