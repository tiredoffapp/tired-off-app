-- Tired-Off private daily submissions and simultaneous reveal.
-- Run once after setup.sql in the Supabase SQL Editor.

create table if not exists public.daily_checkins (
  id uuid primary key default gen_random_uuid(),
  couple_id uuid not null references public.couples(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  checkin_date date not null,
  score integer not null check(score between 0 and 100),
  answers jsonb not null default '{}'::jsonb,
  submitted_at timestamptz not null default now(),
  unique(couple_id,user_id,checkin_date)
);

alter table public.daily_checkins enable row level security;

create or replace function public.my_couple_id()
returns uuid language sql stable security definer set search_path=public as $$
  select couple_id from public.couple_members where user_id=auth.uid() limit 1
$$;

create or replace function public.submit_daily_checkin(
  p_date date,
  p_score integer,
  p_answers jsonb
)
returns jsonb language plpgsql security definer set search_path=public as $$
declare cid uuid; total integer; result jsonb;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  cid:=public.my_couple_id();
  if cid is null then raise exception 'Pair with your partner first'; end if;
  if p_score<0 or p_score>100 then raise exception 'Invalid score'; end if;
  insert into public.daily_checkins(couple_id,user_id,checkin_date,score,answers)
  values(cid,auth.uid(),p_date,p_score,coalesce(p_answers,'{}'::jsonb))
  on conflict(couple_id,user_id,checkin_date) do update set score=excluded.score,answers=excluded.answers,submitted_at=now();
  select count(*) into total from public.daily_checkins where couple_id=cid and checkin_date=p_date;
  if total<2 then return jsonb_build_object('status','waiting','submitted',true); end if;
  select jsonb_build_object('status','revealed','scores',jsonb_agg(jsonb_build_object('user_id',user_id,'score',score) order by submitted_at)) into result
  from public.daily_checkins where couple_id=cid and checkin_date=p_date;
  return result;
end $$;

create or replace function public.get_daily_battle(p_date date)
returns jsonb language plpgsql security definer set search_path=public as $$
declare cid uuid; total integer; mine boolean; result jsonb;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  cid:=public.my_couple_id();
  if cid is null then return jsonb_build_object('status','unpaired'); end if;
  select exists(select 1 from public.daily_checkins where couple_id=cid and user_id=auth.uid() and checkin_date=p_date) into mine;
  select count(*) into total from public.daily_checkins where couple_id=cid and checkin_date=p_date;
  if total<2 then return jsonb_build_object('status',case when mine then 'waiting' else 'open' end,'submitted',mine); end if;
  select jsonb_build_object('status','revealed','scores',jsonb_agg(jsonb_build_object('user_id',user_id,'score',score) order by submitted_at)) into result
  from public.daily_checkins where couple_id=cid and checkin_date=p_date;
  return result;
end $$;

grant execute on function public.my_couple_id() to authenticated;
grant execute on function public.submit_daily_checkin(date,integer,jsonb) to authenticated;
grant execute on function public.get_daily_battle(date) to authenticated;

drop policy if exists "checkins own read" on public.daily_checkins;
create policy "checkins own read" on public.daily_checkins for select using(user_id=auth.uid());
