-- Run in Supabase SQL Editor once. Keeps existing scores and rewards.
-- A concession closes today's battle immediately and gives the other member a win.
create or replace function public.concede_daily_battle(p_date date, p_reason text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare cid uuid;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  if p_date <> (now() at time zone 'Europe/London')::date then raise exception 'Only today can be conceded'; end if;
  cid := public.my_couple_id();
  if cid is null then raise exception 'Pair with your partner first'; end if;
  if (select count(*) from public.couple_members where couple_id=cid) <> 2 then raise exception 'Wait for your partner to join'; end if;
  if exists(select 1 from public.daily_checkins where couple_id=cid and checkin_date=p_date) then
    raise exception 'Today already has a locked score';
  end if;
  insert into public.daily_checkins(couple_id,user_id,checkin_date,score,answers)
  values(cid,auth.uid(),p_date,0,jsonb_build_object('conceded',true,'reason',left(coalesce(p_reason,''),120)))
  on conflict(couple_id,user_id,checkin_date) do nothing;
  if not found then raise exception 'Today is already locked in'; end if;
  return public.get_daily_battle(p_date);
end $$;

create or replace function public.get_daily_battle(p_date date)
returns jsonb language plpgsql security definer set search_path=public as $$
declare cid uuid; total integer; mine boolean; result jsonb; conceder uuid; reason text;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  cid:=public.my_couple_id();
  if cid is null then return jsonb_build_object('status','unpaired'); end if;
  select user_id, answers->>'reason' into conceder, reason from public.daily_checkins
    where couple_id=cid and checkin_date=p_date and answers->>'conceded'='true' limit 1;
  if conceder is not null then
    return jsonb_build_object('status','revealed','concession',jsonb_build_object('user_id',conceder,'reason',reason));
  end if;
  select exists(select 1 from public.daily_checkins
    where couple_id=cid and user_id=auth.uid() and checkin_date=p_date) into mine;
  select count(*) into total from public.daily_checkins where couple_id=cid and checkin_date=p_date;
  if total<2 then return jsonb_build_object('status',case when mine then 'waiting' else 'open' end,'submitted',mine); end if;
  select jsonb_build_object('status','revealed','scores',jsonb_agg(
    jsonb_build_object('user_id',user_id,'score',score,'answers',answers) order by submitted_at)) into result
  from public.daily_checkins where couple_id=cid and checkin_date=p_date;
  return result;
end $$;

create or replace function public.get_shared_game()
returns jsonb language plpgsql security definer set search_path=public as $$
declare cid uuid; result jsonb;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  cid := public.my_couple_id();
  if cid is null then return jsonb_build_object('members','[]'::jsonb,'battles','[]'::jsonb,'rewards','[]'::jsonb); end if;
  select jsonb_build_object(
    'members', coalesce((select jsonb_agg(jsonb_build_object('user_id',cm.user_id,
      'name',coalesce(nullif(u.raw_user_meta_data->>'display_name',''),split_part(u.email,'@',1),'Player')) order by cm.joined_at)
      from public.couple_members cm join auth.users u on u.id=cm.user_id where cm.couple_id=cid),'[]'::jsonb),
    'battles', coalesce((select jsonb_agg(jsonb_build_object('date',d.checkin_date,'scores',d.scores,
      'conceded_by',d.conceded_by,'winner_id',(select cm.user_id from public.couple_members cm
        where cm.couple_id=cid and cm.user_id::text <> d.conceded_by limit 1)) order by d.checkin_date desc)
      from (select c.checkin_date, jsonb_agg(jsonb_build_object('user_id',c.user_id,'score',c.score,'answers',c.answers) order by c.submitted_at) scores,
        max(case when c.answers->>'conceded'='true' then c.user_id::text end) conceded_by
        from public.daily_checkins c where c.couple_id=cid group by c.checkin_date
        having count(*)=2 or bool_or(c.answers->>'conceded'='true')) d),'[]'::jsonb),
    'rewards',coalesce((select jsonb_agg(jsonb_build_object('week_start',wr.week_start,
      'champion_id',wr.champion_id,'reward',wr.reward,'completed_at',wr.completed_at) order by wr.week_start desc)
      from public.weekly_rewards wr where wr.couple_id=cid),'[]'::jsonb)
  ) into result;
  return result;
end $$;

create or replace function public.submit_daily_checkin(p_date date,p_score integer,p_answers jsonb)
returns jsonb language plpgsql security definer set search_path=public as $$
declare cid uuid;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  cid:=public.my_couple_id();
  if cid is null then raise exception 'Pair with your partner first'; end if;
  if exists(select 1 from public.daily_checkins where couple_id=cid and checkin_date=p_date
    and answers->>'conceded'='true') then raise exception 'Today was conceded already'; end if;
  if p_score is null or p_score<0 or p_score>100 then raise exception 'Invalid score'; end if;
  if p_answers is null or jsonb_typeof(p_answers)<>'object' or p_answers ? 'conceded' then raise exception 'Invalid answers'; end if;
  insert into public.daily_checkins(couple_id,user_id,checkin_date,score,answers)
    values(cid,auth.uid(),p_date,p_score,p_answers)
    on conflict(couple_id,user_id,checkin_date) do nothing;
  if not found then raise exception 'Your score is already locked in for today'; end if;
  return public.get_daily_battle(p_date);
end $$;

grant execute on function public.concede_daily_battle(date,text) to authenticated;
grant execute on function public.get_daily_battle(date) to authenticated;
grant execute on function public.get_shared_game() to authenticated;
grant execute on function public.submit_daily_checkin(date,integer,jsonb) to authenticated;
