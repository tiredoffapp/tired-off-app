-- Run once in Supabase SQL Editor after daily-battles.sql.
-- Show both partners' detailed answers only after both have submitted.
-- Existing check-ins and weekly scores are kept.

create or replace function public.get_daily_battle(p_date date)
returns jsonb language plpgsql security definer set search_path=public as $$
declare cid uuid; total integer; mine boolean; result jsonb;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  cid:=public.my_couple_id();
  if cid is null then return jsonb_build_object('status','unpaired'); end if;
  select exists(select 1 from public.daily_checkins
    where couple_id=cid and user_id=auth.uid() and checkin_date=p_date) into mine;
  select count(*) into total from public.daily_checkins
    where couple_id=cid and checkin_date=p_date;
  if total<2 then
    return jsonb_build_object('status',case when mine then 'waiting' else 'open' end,'submitted',mine);
  end if;
  select jsonb_build_object('status','revealed','scores',
    jsonb_agg(jsonb_build_object('user_id',user_id,'score',score,'answers',answers)
      order by submitted_at)) into result
  from public.daily_checkins where couple_id=cid and checkin_date=p_date;
  return result;
end $$;

create or replace function public.submit_daily_checkin(
  p_date date, p_score integer, p_answers jsonb
)
returns jsonb language plpgsql security definer set search_path=public as $$
declare cid uuid;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  cid:=public.my_couple_id();
  if cid is null then raise exception 'Pair with your partner first'; end if;
  if p_score is null or p_score<0 or p_score>100 then raise exception 'Invalid score'; end if;
  if p_answers is null or jsonb_typeof(p_answers)<>'object' then raise exception 'Invalid answers'; end if;
  insert into public.daily_checkins(couple_id,user_id,checkin_date,score,answers)
    values(cid,auth.uid(),p_date,p_score,p_answers)
    on conflict(couple_id,user_id,checkin_date) do nothing;
  if not found then raise exception 'Your score is already locked in for today'; end if;
  return public.get_daily_battle(p_date);
end $$;

grant execute on function public.get_daily_battle(date) to authenticated;
grant execute on function public.submit_daily_checkin(date,integer,jsonb) to authenticated;
