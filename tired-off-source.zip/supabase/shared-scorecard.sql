-- Shared, weekly locked scorecard and exhaustion deck.

create table if not exists public.shared_scorecards (
  couple_id uuid primary key references public.couples(id) on delete cascade,
  active_week date not null,
  active_metrics jsonb not null,
  active_cards jsonb not null,
  pending_metrics jsonb,
  pending_cards jsonb,
  updated_by uuid references auth.users(id),
  updated_at timestamptz not null default now()
);

alter table public.shared_scorecards enable row level security;

create or replace function public.get_shared_scorecard()
returns jsonb language plpgsql security definer set search_path=public as $$
declare cid uuid; monday date; result jsonb;
begin
  cid:=public.my_couple_id();
  if cid is null then raise exception 'Pair with your partner first'; end if;
  monday:=current_date-(extract(isodow from current_date)::integer-1);
  insert into public.shared_scorecards(couple_id,active_week,active_metrics,active_cards,updated_by)
  values(cid,monday,
    '[{"id":"sleep","label":"Hours slept","min":0,"max":12,"step":0.5,"suffix":" hrs","weight":8,"invert":8,"core":true},{"id":"work","label":"Hours worked","min":0,"max":16,"step":0.5,"suffix":" hrs","weight":1.6,"core":true},{"id":"wakeups","label":"Night wake-ups","min":0,"max":10,"step":1,"suffix":"","weight":5,"core":true},{"id":"awake","label":"Minutes awake overnight","min":0,"max":240,"step":10,"suffix":" min","weight":0.07,"core":true},{"id":"chores","label":"Housework","min":0,"max":8,"step":0.5,"suffix":" hrs","weight":3},{"id":"childcare","label":"Childcare","min":0,"max":24,"step":0.5,"suffix":" hrs","weight":4},{"id":"stress","label":"Stress / mental load","min":0,"max":5,"step":1,"suffix":"/5","weight":4},{"id":"physical","label":"Physical effort","min":0,"max":5,"step":1,"suffix":"/5","weight":2}]'::jsonb,
    '[{"id":"sick","emoji":"🤒","label":"Sick child","points":15},{"id":"feed","emoji":"🍼","label":"Night feed","points":12},{"id":"snore","emoji":"💤","label":"Partner snored","points":5},{"id":"liein","emoji":"🛏️","label":"Had a lie-in","points":-10},{"id":"late","emoji":"💼","label":"Worked late","points":10},{"id":"nap","emoji":"😌","label":"Afternoon nap","points":-10}]'::jsonb,
    auth.uid()) on conflict(couple_id) do nothing;
  update public.shared_scorecards set active_week=monday,
    active_metrics=coalesce(pending_metrics,active_metrics),active_cards=coalesce(pending_cards,active_cards),
    pending_metrics=null,pending_cards=null
  where couple_id=cid and active_week<monday;
  select jsonb_build_object('active_week',active_week,'active_metrics',active_metrics,'active_cards',active_cards,
    'pending_metrics',pending_metrics,'pending_cards',pending_cards,'next_monday',monday+7)
  into result from public.shared_scorecards where couple_id=cid;
  return result;
end $$;

create or replace function public.save_shared_scorecard(p_metrics jsonb,p_cards jsonb)
returns void language plpgsql security definer set search_path=public as $$
declare cid uuid;
begin
  cid:=public.my_couple_id();
  if cid is null then raise exception 'Pair with your partner first'; end if;
  if jsonb_typeof(p_metrics)<>'array' or jsonb_array_length(p_metrics)<4 or jsonb_array_length(p_metrics)>10 then raise exception 'Choose 4 to 10 measurements'; end if;
  if jsonb_typeof(p_cards)<>'array' or jsonb_array_length(p_cards)<4 or jsonb_array_length(p_cards)>12 then raise exception 'Choose 4 to 12 cards'; end if;
  perform public.get_shared_scorecard();
  update public.shared_scorecards set pending_metrics=p_metrics,pending_cards=p_cards,updated_by=auth.uid(),updated_at=now() where couple_id=cid;
end $$;

grant execute on function public.get_shared_scorecard() to authenticated;
grant execute on function public.save_shared_scorecard(jsonb,jsonb) to authenticated;
