-- Run once in Supabase SQL Editor. Restores one shared reward shuffle per week.
create table if not exists public.weekly_reward_shuffles (
  couple_id uuid not null references public.couples(id) on delete cascade,
  week_start date not null,
  used_by uuid not null references auth.users(id) on delete cascade,
  used_at timestamptz not null default now(),
  primary key (couple_id, week_start)
);

alter table public.weekly_reward_shuffles enable row level security;

create or replace function public.use_weekly_reward_shuffle(p_week_start date)
returns void language plpgsql security definer set search_path=public as $$
declare cid uuid; london_now timestamp; current_monday date;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  cid := public.my_couple_id();
  if cid is null then raise exception 'Pair with your partner first'; end if;
  london_now := now() at time zone 'Europe/London';
  current_monday := london_now::date - (extract(isodow from london_now)::integer - 1);
  if p_week_start <> current_monday then raise exception 'Only this week can be shuffled'; end if;
  if extract(isodow from london_now) <> 7 or london_now::time < time '19:00' then
    raise exception 'Rewards unlock on Sunday at 7pm';
  end if;
  insert into public.weekly_reward_shuffles(couple_id,week_start,used_by)
  values(cid,p_week_start,auth.uid())
  on conflict(couple_id,week_start) do nothing;
  if not found then raise exception 'This week''s shuffle has already been used'; end if;
end $$;

create or replace function public.get_shared_game()
returns jsonb language plpgsql security definer set search_path=public as $$
declare cid uuid; result jsonb;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  cid := public.my_couple_id();
  if cid is null then return jsonb_build_object('members','[]'::jsonb,'battles','[]'::jsonb,'rewards','[]'::jsonb,'reward_shuffles','[]'::jsonb); end if;
  select jsonb_build_object(
    'members', coalesce((select jsonb_agg(jsonb_build_object('user_id',cm.user_id,
      'name',coalesce(nullif(u.raw_user_meta_data->>'display_name',''),split_part(u.email,'@',1),'Player')) order by cm.joined_at)
      from public.couple_members cm join auth.users u on u.id=cm.user_id where cm.couple_id=cid),'[]'::jsonb),
    'battles', coalesce((select jsonb_agg(jsonb_build_object('date',d.checkin_date,'scores',d.scores,
      'conceded_by',d.conceded_by,'winner_id',(select cm.user_id from public.couple_members cm
        where cm.couple_id=cid and cm.user_id::text <> d.conceded_by limit 1)) order by d.checkin_date desc)
      from (select c.checkin_date,
        jsonb_agg(jsonb_build_object('user_id',c.user_id,'score',c.score,'answers',c.answers) order by c.submitted_at) scores,
        max(case when c.answers->>'conceded'='true' then c.user_id::text end) conceded_by
        from public.daily_checkins c where c.couple_id=cid group by c.checkin_date
        having count(*)=2 or bool_or(c.answers->>'conceded'='true')) d),'[]'::jsonb),
    'rewards',coalesce((select jsonb_agg(jsonb_build_object('week_start',wr.week_start,
      'champion_id',wr.champion_id,'reward',wr.reward,'completed_at',wr.completed_at) order by wr.week_start desc)
      from public.weekly_rewards wr where wr.couple_id=cid),'[]'::jsonb),
    'reward_shuffles',coalesce((select jsonb_agg(wrs.week_start order by wrs.week_start desc)
      from public.weekly_reward_shuffles wrs where wrs.couple_id=cid),'[]'::jsonb)
  ) into result;
  return result;
end $$;

grant execute on function public.use_weekly_reward_shuffle(date) to authenticated;
grant execute on function public.get_shared_game() to authenticated;
