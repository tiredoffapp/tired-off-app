-- Tired-Off account and couple-pairing foundation.
-- Run once in Supabase: SQL Editor > New query > paste > Run.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists public.couples (
  id uuid primary key default gen_random_uuid(),
  name text not null default 'Our Tired-Off',
  invite_code text not null unique,
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.couple_members (
  couple_id uuid not null references public.couples(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('creator','partner')),
  joined_at timestamptz not null default now(),
  primary key (couple_id,user_id),
  unique (user_id)
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,display_name)
  values(new.id,coalesce(new.raw_user_meta_data->>'display_name',split_part(new.email,'@',1)))
  on conflict(id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_couple_member(target uuid)
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.couple_members where couple_id=target and user_id=auth.uid())
$$;

create or replace function public.create_tired_off_couple(couple_name text default 'Our Tired-Off')
returns table(couple_id uuid,invite_code text)
language plpgsql security definer set search_path=public as $$
declare new_id uuid; new_code text;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  if exists(select 1 from public.couple_members where user_id=auth.uid()) then raise exception 'You are already paired'; end if;
  loop
    new_code:=upper(substr(replace(gen_random_uuid()::text,'-',''),1,8));
    exit when not exists(select 1 from public.couples where couples.invite_code=new_code);
  end loop;
  insert into public.couples(name,invite_code,created_by) values(coalesce(nullif(trim(couple_name),''),'Our Tired-Off'),new_code,auth.uid()) returning id into new_id;
  insert into public.couple_members(couple_id,user_id,role) values(new_id,auth.uid(),'creator');
  return query select new_id,new_code;
end $$;

create or replace function public.join_tired_off_couple(code text)
returns uuid language plpgsql security definer set search_path=public as $$
declare target uuid;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  if exists(select 1 from public.couple_members where user_id=auth.uid()) then raise exception 'You are already paired'; end if;
  select id into target from public.couples where invite_code=upper(trim(code)) for update;
  if target is null then raise exception 'Invite code not found'; end if;
  if (select count(*) from public.couple_members where couple_id=target)>=2 then raise exception 'This couple already has two members'; end if;
  insert into public.couple_members(couple_id,user_id,role) values(target,auth.uid(),'partner');
  return target;
end $$;

alter table public.profiles enable row level security;
alter table public.couples enable row level security;
alter table public.couple_members enable row level security;

drop policy if exists "profiles own read" on public.profiles;
create policy "profiles own read" on public.profiles for select using(id=auth.uid());
drop policy if exists "profiles own update" on public.profiles;
create policy "profiles own update" on public.profiles for update using(id=auth.uid());
drop policy if exists "couples member read" on public.couples;
create policy "couples member read" on public.couples for select using(public.is_couple_member(id));
drop policy if exists "members shared read" on public.couple_members;
create policy "members shared read" on public.couple_members for select using(public.is_couple_member(couple_id));

grant execute on function public.create_tired_off_couple(text) to authenticated;
grant execute on function public.join_tired_off_couple(text) to authenticated;
