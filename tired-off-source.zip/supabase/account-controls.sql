-- Safe account controls for Tired-Off.
-- Run once in Supabase: SQL Editor > New query > paste everything > Run.

create or replace function public.leave_tired_off_couple()
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  cid uuid;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  select couple_id into cid from public.couple_members where user_id = auth.uid();
  if cid is null then return; end if;

  update public.couples
  set created_by = (
    select user_id from public.couple_members
    where couple_id = cid and user_id <> auth.uid()
    order by joined_at limit 1
  )
  where id = cid
    and created_by = auth.uid()
    and exists (select 1 from public.couple_members where couple_id = cid and user_id <> auth.uid());

  delete from public.couple_members where user_id = auth.uid();
  delete from public.couples
  where id = cid and not exists (
    select 1 from public.couple_members where couple_id = cid
  );
end;
$$;

create or replace function public.delete_my_tired_off_account()
returns void
language plpgsql
security definer
set search_path = public, auth
as $$
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  update public.couples c
  set created_by = (
    select cm.user_id from public.couple_members cm
    where cm.couple_id = c.id and cm.user_id <> auth.uid()
    order by cm.joined_at limit 1
  )
  where c.created_by = auth.uid()
    and exists (select 1 from public.couple_members cm where cm.couple_id = c.id and cm.user_id <> auth.uid());
  delete from auth.users where id = auth.uid();
end;
$$;

grant execute on function public.leave_tired_off_couple() to authenticated;
grant execute on function public.delete_my_tired_off_account() to authenticated;
