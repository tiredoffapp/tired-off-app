import { createClient } from "npm:@supabase/supabase-js@2";
import { GoogleAuth } from "npm:google-auth-library@9";

const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type" };

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const authorization = req.headers.get("Authorization") || "";
    const userClient = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: authorization } } });
    const { data: { user } } = await userClient.auth.getUser();
    if (!user) return new Response("Unauthorized", { status: 401, headers: cors });
    const { message_id } = await req.json();
    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: message } = await admin.from("tired_talk_messages").select("id,sender_id,recipient_id,message_id,message_text").eq("id", message_id).single();
    if (!message || message.sender_id !== user.id) return new Response("Forbidden", { status: 403, headers: cors });
    const { data: devices } = await admin.from("push_devices").select("token").eq("user_id", message.recipient_id).eq("enabled", true);
    if (!devices?.length) return Response.json({ sent: 0 }, { headers: cors });
    const serviceAccount = JSON.parse(Deno.env.get("FIREBASE_SERVICE_ACCOUNT")!);
    const auth = new GoogleAuth({ credentials: serviceAccount, scopes: ["https://www.googleapis.com/auth/firebase.messaging"] });
    const accessToken = await auth.getAccessToken();
    const presets: Record<string,string> = {
      walking_to_work:"I’m already tired and I’ve only just left the house 😴", running_on_fumes:"Running on fumes today. Send snacks.", tea_please:"Any chance of a cup of tea? ☕", sofa_claim:"I’m claiming five minutes on the sofa.", take_over:"Could you take over for 20 minutes? ❤️", nap_request:"I would like to formally request a nap.", score_suspicious:"Your tiredness score is suspiciously low 👀", proud_of_you:"You’re doing brilliantly. Nearly there ❤️", truce:"Truce? Let’s order dinner.", on_my_way:"On my way home. Save me a seat.", rough_night:"That was a rough night. We’ve got this.", you_win_today:"I concede. You win the tiredness crown today 👑"
    };
    const body = message.message_id === "custom" ? message.message_text : presets[message.message_id] || "Your partner sent you a Tired Talk.";
    const results = await Promise.all(devices.map(({ token }) => fetch(`https://fcm.googleapis.com/v1/projects/${serviceAccount.project_id}/messages:send`, {
      method: "POST", headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
      body: JSON.stringify({ message: { token, notification: { title: "Tired Talk 💬", body }, data: { destination: "talk" }, android: { priority: "high", notification: { sound: "default", channel_id: "tired_talk" } } } }),
    })));
    return Response.json({ sent: results.filter((result) => result.ok).length }, { headers: cors });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Push failed" }, { status: 500, headers: cors });
  }
});
