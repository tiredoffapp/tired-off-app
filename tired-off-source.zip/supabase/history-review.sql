-- Run once in Supabase SQL Editor. This makes locked historical answers
-- available to the read-only Championship review screen.
create or replace function public.get_shared_game()
returns jsonb language plpgsql security definer set search_path=public as $$
declare cid uuid; result jsonb;
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  cid := public.my_couple_id();
  if cid is null then return jsonb_build_object('members','[]'::jsonb,'battles','[]'::jsonb,'rewards','[]'::jsonb); end if;
  select jsonb_build_object(
    'members', coalesce((select jsonb_agg(jsonb_build_object('user_id',cm.user_id,
      'name',coalesce(nullif(u.raw_user_meta_data->>'display_name',''),split_part(u.email,'@',1),'Player')) order by cm.joined_at)
      from public.couple_members cm join auth.users u on u.id=cm.user_id where cm.couple_id=cid),'[]'::jsonb),
    'battles', coalesce((select jsonb_agg(jsonb_build_object('date',d.checkin_date,'scores',d.scores,
      'conceded_by',d.conceded_by,'winner_id',(select cm.user_id from public.couple_members cm
        where cm.couple_id=cid and cm.user_id::text <> d.conceded_by limit 1)) order by d.checkin_date desc)
      from (select c.checkin_date,
        jsonb_agg(jsonb_build_object('user_id',c.user_id,'score',c.score,'answers',c.answers) order by c.submitted_at) scores,
        max(case when c.answers->>'conceded'='true' then c.user_id::text end) conceded_by
        from public.daily_checkins c where c.couple_id=cid group by c.checkin_date
        having count(*)=2 or bool_or(c.answers->>'conceded'='true')) d),'[]'::jsonb),
    'rewards',coalesce((select jsonb_agg(jsonb_build_object('week_start',wr.week_start,
      'champion_id',wr.champion_id,'reward',wr.reward,'completed_at',wr.completed_at) order by wr.week_start desc)
      from public.weekly_rewards wr where wr.couple_id=cid),'[]'::jsonb)
  ) into result;
  return result;
end $$;

grant execute on function public.get_shared_game() to authenticated;
