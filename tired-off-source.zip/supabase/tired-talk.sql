-- Tired Talk: run once in Supabase SQL Editor. No existing scores are changed.
create table if not exists public.tired_talk_messages (
  id uuid primary key default gen_random_uuid(),
  couple_id uuid not null references public.couples(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  recipient_id uuid not null references auth.users(id) on delete cascade,
  message_text text,
  message_id text not null check (message_id in (
    'walking_to_work','running_on_fumes','tea_please','sofa_claim','take_over',
    'nap_request','score_suspicious','proud_of_you','truce','on_my_way',
    'rough_night','you_win_today','custom'
  )),
  created_at timestamptz not null default now(),
  read_at timestamptz,
  check (sender_id <> recipient_id),
  constraint tired_talk_custom_text_check check (
    (message_id = 'custom' and char_length(trim(message_text)) between 1 and 300)
    or (message_id <> 'custom' and message_text is null)
  )
);

create index if not exists tired_talk_recent
  on public.tired_talk_messages (couple_id, created_at desc);

alter table public.tired_talk_messages enable row level security;

drop policy if exists "talk members read" on public.tired_talk_messages;
create policy "talk members read" on public.tired_talk_messages
for select to authenticated using (
  exists (select 1 from public.couple_members m
    where m.couple_id = tired_talk_messages.couple_id and m.user_id = auth.uid())
  and (sender_id = auth.uid() or recipient_id = auth.uid())
);

drop policy if exists "talk sender create" on public.tired_talk_messages;
create policy "talk sender create" on public.tired_talk_messages
for insert to authenticated with check (
  sender_id = auth.uid()
  and exists (select 1 from public.couple_members m
    where m.couple_id = tired_talk_messages.couple_id and m.user_id = auth.uid())
  and exists (select 1 from public.couple_members m
    where m.couple_id = tired_talk_messages.couple_id and m.user_id = recipient_id)
);

drop policy if exists "talk recipient mark read" on public.tired_talk_messages;
create policy "talk recipient mark read" on public.tired_talk_messages
for update to authenticated using (recipient_id = auth.uid())
with check (recipient_id = auth.uid());

-- Only read_at may be changed after a message has been sent.
create or replace function public.tired_talk_guard_update()
returns trigger language plpgsql set search_path = public as $$
begin
  if new.id is distinct from old.id or new.couple_id is distinct from old.couple_id
    or new.sender_id is distinct from old.sender_id
    or new.recipient_id is distinct from old.recipient_id
    or new.message_id is distinct from old.message_id
    or new.message_text is distinct from old.message_text
    or new.created_at is distinct from old.created_at then
    raise exception 'Sent messages cannot be changed';
  end if;
  if old.read_at is not null and new.read_at is distinct from old.read_at then
    raise exception 'Read messages cannot be changed';
  end if;
  return new;
end $$;

drop trigger if exists tired_talk_guard_update on public.tired_talk_messages;
create trigger tired_talk_guard_update before update on public.tired_talk_messages
for each row execute function public.tired_talk_guard_update();

revoke all on public.tired_talk_messages from anon;
grant select, insert on public.tired_talk_messages to authenticated;
grant update (read_at) on public.tired_talk_messages to authenticated;
