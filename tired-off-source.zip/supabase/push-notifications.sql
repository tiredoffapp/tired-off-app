-- Run once in Supabase SQL Editor. Stores each signed-in phone's FCM token.
create table if not exists public.push_devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  token text not null unique,
  platform text not null check (platform in ('android','ios')),
  enabled boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.push_devices enable row level security;

drop policy if exists "push devices own read" on public.push_devices;
create policy "push devices own read" on public.push_devices
for select using (user_id = auth.uid());

create or replace function public.register_push_device(p_token text, p_platform text)
returns void language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is null then raise exception 'Sign in required'; end if;
  if length(trim(coalesce(p_token,''))) < 20 then raise exception 'Invalid notification token'; end if;
  if p_platform not in ('android','ios') then raise exception 'Invalid platform'; end if;
  insert into public.push_devices(user_id,token,platform,enabled,updated_at)
  values(auth.uid(),trim(p_token),p_platform,true,now())
  on conflict(token) do update set user_id=auth.uid(),platform=excluded.platform,enabled=true,updated_at=now();
end $$;

grant execute on function public.register_push_device(text,text) to authenticated;
revoke all on public.push_devices from anon;
grant select on public.push_devices to authenticated;
