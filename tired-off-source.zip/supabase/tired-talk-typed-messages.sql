-- Run once after tired-talk.sql. Existing messages are kept.
alter table public.tired_talk_messages
  add column if not exists message_text text;

alter table public.tired_talk_messages
  drop constraint if exists tired_talk_messages_message_id_check;

alter table public.tired_talk_messages
  add constraint tired_talk_messages_message_id_check check (message_id in (
    'walking_to_work','running_on_fumes','tea_please','sofa_claim','take_over',
    'nap_request','score_suspicious','proud_of_you','truce','on_my_way',
    'rough_night','you_win_today','custom'
  ));

alter table public.tired_talk_messages
  drop constraint if exists tired_talk_custom_text_check;

alter table public.tired_talk_messages
  add constraint tired_talk_custom_text_check check (
    (message_id = 'custom' and char_length(trim(message_text)) between 1 and 300)
    or (message_id <> 'custom' and message_text is null)
  );

create or replace function public.tired_talk_guard_update()
returns trigger language plpgsql set search_path = public as $$
begin
  if new.id is distinct from old.id or new.couple_id is distinct from old.couple_id
    or new.sender_id is distinct from old.sender_id
    or new.recipient_id is distinct from old.recipient_id
    or new.message_id is distinct from old.message_id
    or new.message_text is distinct from old.message_text
    or new.created_at is distinct from old.created_at then
    raise exception 'Sent messages cannot be changed';
  end if;
  if old.read_at is not null and new.read_at is distinct from old.read_at then
    raise exception 'Read messages cannot be changed';
  end if;
  return new;
end $$;
