package uk.co.tiredoff.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
