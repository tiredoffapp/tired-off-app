import { App } from "@capacitor/app";
import { Browser } from "@capacitor/browser";
import { Capacitor } from "@capacitor/core";
import { supabase } from "@/lib/supabase";

export const NATIVE_AUTH_CALLBACK = "tiredoff://auth/callback";

export function isNativeApp() {
  return Capacitor.isNativePlatform();
}

export function authRedirectUrl() {
  return isNativeApp() ? NATIVE_AUTH_CALLBACK : window.location.origin;
}

export async function startGoogleOAuth() {
  const native = isNativeApp();
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: "google",
    options: {
      redirectTo: authRedirectUrl(),
      skipBrowserRedirect: native,
    },
  });
  if (error) throw error;
  if (native && data.url) {
    await Browser.open({ url: data.url });
  }
}

async function finishNativeAuth(url: string) {
  if (!url.startsWith(NATIVE_AUTH_CALLBACK)) return;
  const callback = new URL(url);
  const oauthError = callback.searchParams.get("error_description") || callback.searchParams.get("error");
  if (oauthError) throw new Error(oauthError);
  const code = callback.searchParams.get("code");
  if (!code) throw new Error("Google did not return a sign-in code.");
  const { error } = await supabase.auth.exchangeCodeForSession(code);
  if (error) throw error;
  await Browser.close().catch(() => undefined);
}

export async function listenForNativeAuth(onError?: (message: string) => void) {
  if (!isNativeApp()) return () => undefined;
  const handleUrl = (url: string) => finishNativeAuth(url).catch((error) => onError?.(error instanceof Error ? error.message : "Google sign-in could not be completed."));
  const listener = await App.addListener("appUrlOpen", ({ url }) => handleUrl(url));
  const launch = await App.getLaunchUrl();
  if (launch?.url) await handleUrl(launch.url);
  return () => listener.remove();
}
