import { Capacitor } from "@capacitor/core";
import { PushNotifications } from "@capacitor/push-notifications";
import { supabase } from "@/lib/supabase";

const preferenceKey = "tired-off-native-notifications";
let listenersReady = false;

export function supportsNativeNotifications() {
  return Capacitor.isNativePlatform();
}

export function nativeNotificationsEnabled() {
  return supportsNativeNotifications() && localStorage.getItem(preferenceKey) === "yes";
}

async function ensureListeners() {
  if (listenersReady || !supportsNativeNotifications()) return;
  listenersReady = true;
  await PushNotifications.addListener("registration", async ({ value }) => {
    const { error } = await supabase.rpc("register_push_device", {
      p_token: value,
      p_platform: Capacitor.getPlatform(),
    });
    if (!error) localStorage.setItem(preferenceKey, "yes");
  });
  await PushNotifications.addListener("registrationError", ({ error }) => {
    console.error("Tired-Off push registration failed", error);
  });
  await PushNotifications.addListener("pushNotificationActionPerformed", () => {
    window.dispatchEvent(new CustomEvent("tired-off:open-talk"));
  });
}

export async function enableNativeNotifications() {
  if (!supportsNativeNotifications()) return false;
  await ensureListeners();
  let permission = await PushNotifications.checkPermissions();
  if (permission.receive === "prompt") permission = await PushNotifications.requestPermissions();
  if (permission.receive !== "granted") return false;
  localStorage.setItem(preferenceKey, "yes");
  await PushNotifications.register();
  return true;
}

export async function restoreNativeNotifications() {
  if (!nativeNotificationsEnabled()) return;
  await ensureListeners();
  const permission = await PushNotifications.checkPermissions();
  if (permission.receive === "granted") await PushNotifications.register();
}
